(() => {
  'use strict';
  const N = s => (s || '').toString().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
  const V = e => { if(!e) return false; const r=e.getBoundingClientRect(); const s=getComputedStyle(e); return r.width>1&&r.height>1&&s.display!=='none'&&s.visibility!=='hidden'; };
  let port = null, command = null, timer = null, passes = 0, exportClicked = false, activeProfile = 'import';
  let objectBlobs = new Map();

  function connect(){
    try {
      port = browser.runtime.connectNative('vbspp');
      port.onMessage.addListener(msg => {
        if(!msg || !msg.type) return;
        if(msg.type === 'sync') {
          command = msg; activeProfile = msg.phase || 'import'; passes=0; exportClicked=false;
          status('Automatika ZSDIS: hľadám intervalové dáta…');
          startLoop();
        }
        if(msg.type === 'ping') send({type:'pong',url:location.href,title:document.title});
      });
      port.onDisconnect.addListener(()=>{port=null; setTimeout(connect,800)});
      send({type:'page',url:location.href,title:document.title,login:isLogin(),bodyLength:(document.body?.innerText||'').length});
    } catch(e) { setTimeout(connect,1000); }
  }
  function send(o){ try{ if(port) port.postMessage(o); }catch(e){} }
  function status(text){ send({type:'status',text,url:location.href}); }
  function isLogin(){ const b=N(document.body?.innerText); return !!document.querySelector('input[type=password]') || (/prihlas/.test(b)&&/hesl/.test(b)); }
  function byText(re, selector='a,button,[role=button],li,span,div,td'){ return [...document.querySelectorAll(selector)].filter(V).find(e=>re.test(N(e.innerText||e.textContent))); }
  function clickText(re){ const e=byText(re); if(e){ e.click(); return true; } return false; }
  function dateSk(s){ const m=(s||'').match(/(\d{4})-(\d{2})-(\d{2})/); return m?`${m[3]}.${m[2]}.${m[1]}`:s; }
  function setInput(el,val){
    if(!el) return false;
    try {
      const proto = el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto,'value')?.set;
      if(setter) setter.call(el,val); else el.value=val;
      el.dispatchEvent(new Event('input',{bubbles:true})); el.dispatchEvent(new Event('change',{bubbles:true})); el.dispatchEvent(new Event('blur',{bubbles:true}));
      return true;
    } catch(e){ return false; }
  }
  function setDates(){
    if(!command) return false;
    const start=command.startDate||'', end=command.endDate||'';
    let changed=false;
    const dates=[...document.querySelectorAll('input[type=date]')].filter(V);
    if(dates.length>=2){ changed|=setInput(dates[0],start); changed|=setInput(dates[1],end); return !!changed; }
    const cands=[...document.querySelectorAll('input')].filter(e=>V(e)&&(/datum|date|od|do/.test(N((e.placeholder||'')+' '+(e.getAttribute('aria-label')||'')))));
    if(cands.length>=2){ changed|=setInput(cands[0],dateSk(start)); changed|=setInput(cands[1],dateSk(end)); }
    return !!changed;
  }
  function setProfile(){
    const want=activeProfile;
    for(const s of [...document.querySelectorAll('select')].filter(V)){
      const opts=[...s.options];
      let idx=-1;
      if(want==='import') idx=opts.findIndex(o=>{const t=N(o.text);return (/p\+/.test(t)||/odber|spotreba|import/.test(t))&&!/dodav|p-/.test(t)});
      else idx=opts.findIndex(o=>{const t=N(o.text);return /p-|dodavka|pretok|prebytok|export/.test(t)});
      if(idx>=0){ if(s.selectedIndex!==idx){s.selectedIndex=idx;s.dispatchEvent(new Event('input',{bubbles:true}));s.dispatchEvent(new Event('change',{bubbles:true}));} return true; }
    }
    // Angular/Material combobox - klikneme naň a následne na text profilu.
    const combo=[...document.querySelectorAll('[role=combobox],mat-select,.mat-select-trigger')].find(V);
    if(combo){
      const txt=N(combo.innerText);
      const already=want==='import'?(/p\+|odber|spotreba/.test(txt)&&!/dodav/.test(txt)):(/p-|dodavka|pretok|prebytok/.test(txt));
      if(already) return true;
      combo.click();
      setTimeout(()=>{
        const re=want==='import'?/p\+|odber|spotreba/:/p-|dodavka|pretok|prebytok/;
        const opt=byText(re,'[role=option],mat-option,.mat-option,li,div,span'); if(opt) opt.click();
      },350);
      return true;
    }
    return false;
  }
  function chooseFirstMeter(){
    const body=N(document.body?.innerText);
    if(!/odberne miesta/.test(body)) return false;
    const eic=[...document.querySelectorAll('a,button,tr,td,div')].filter(V).find(e=>/24z[a-z0-9]{8,}/i.test((e.innerText||'').replace(/\s/g,'')));
    if(eic){ eic.click(); return true; }
    const row=[...document.querySelectorAll('tbody tr')].filter(V)[0]; if(row){ row.click(); return true; }
    return false;
  }
  function automate(){
    if(!command) return;
    passes++;
    const body=N(document.body?.innerText);
    if(isLogin()) { status('Prihlás sa do ZSDIS. Po prihlásení budem pokračovať automaticky.'); return; }
    if(/intervalove data/.test(body)){
      setDates(); setProfile();
      // Niektoré formuláre vyžadujú tlačidlo Zobraziť/Vyhľadať pred exportom.
      if(!exportClicked && passes%4===0){ const show=byText(/^(zobrazit|vyhladat|hladat|potvrdit)$/,'button,a,[role=button]'); if(show){show.click(); status('Načítavam intervalové dáta…'); return;} }
      const ex=byText(/^export$|export dat|exportovat/,'button,a,[role=button],span,div');
      if(ex && !exportClicked){ exportClicked=true; status(activeProfile==='import'?'Exportujem odber zo siete…':'Exportujem dodávku do siete…'); ex.click(); setTimeout(()=>{if(exportClicked) exportClicked=false;},12000); return; }
      status('Som v intervalových dátach, čakám na možnosť Export…');
      return;
    }
    if(/odberne miesta/.test(body)){
      if(clickText(/intervalove data/)){status('Otváram intervalové dáta…');return;}
      if(chooseFirstMeter()){status('Vyberám odberné miesto…');return;}
    }
    if(clickText(/^odberne miesta$/)){status('Otváram odberné miesta…');return;}
    if(passes>45) status('Automatika nenašla Intervalové dáta. Otvor ich ručne; export potom prevezmem automaticky.');
  }
  function startLoop(){ if(timer) clearInterval(timer); automate(); timer=setInterval(automate,1200); }

  function bufToB64(buf){ let u=new Uint8Array(buf), s=''; const step=0x8000; for(let i=0;i<u.length;i+=step)s+=String.fromCharCode(...u.subarray(i,i+step)); return btoa(s); }
  async function sendBlob(blob,name='export.xlsx'){
    try{
      if(!blob || blob.size<32) return;
      const b64=bufToB64(await blob.arrayBuffer());
      const id='f'+Date.now()+Math.random().toString(16).slice(2); const chunk=180000; const total=Math.ceil(b64.length/chunk);
      send({type:'fileStart',id,name,mime:blob.type||'application/octet-stream',profile:activeProfile,total});
      for(let i=0;i<total;i++) send({type:'fileChunk',id,index:i,data:b64.slice(i*chunk,(i+1)*chunk)});
      send({type:'fileEnd',id});
      status('Export zachytený, spracúvam ho v aplikácii…'); exportClicked=false;
    }catch(e){send({type:'error',text:'Zachytenie exportu zlyhalo: '+e.message});}
  }

  // Zachytenie blob downloadov.
  try{
    const origCreate=URL.createObjectURL.bind(URL);
    URL.createObjectURL=function(blob){ const u=origCreate(blob); try{objectBlobs.set(u,blob); setTimeout(()=>objectBlobs.delete(u),60000);}catch(e){} return u; };
    document.addEventListener('click',ev=>{
      const a=ev.target?.closest?.('a'); if(!a) return;
      const text=N(a.innerText||a.textContent);
      const href=a.href||'';
      if(a.download || /export/.test(text)){
        if(href.startsWith('blob:') && objectBlobs.has(href)){ ev.preventDefault(); sendBlob(objectBlobs.get(href),a.download||'export.xlsx'); }
        else if(href && /^https?:/.test(href) && /export|download|excel|xls|csv/i.test(href)){ ev.preventDefault(); fetch(href,{credentials:'include'}).then(r=>r.blob()).then(b=>sendBlob(b,a.download||'export.xlsx')).catch(()=>{}); }
      }
    },true);
  }catch(e){}

  // Zachytenie fetch exportov.
  try{
    const ofetch=window.fetch;
    window.fetch=async function(...args){ const r=await ofetch.apply(this,args); try{ const url=String(args[0]?.url||args[0]||r.url||''); const ct=r.headers.get('content-type')||''; const cd=r.headers.get('content-disposition')||''; if(/excel|spreadsheet|csv|octet-stream/i.test(ct)||/attachment/i.test(cd)||/export|download/i.test(url)){ const c=r.clone(); c.blob().then(b=>sendBlob(b,(cd.match(/filename\*?=(?:UTF-8''|\")?([^\";]+)/i)||[])[1]||'export.xlsx')).catch(()=>{}); } }catch(e){} return r; };
  }catch(e){}

  // Zachytenie XHR blob/arraybuffer exportov.
  try{
    const oopen=XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open=function(method,url,...rest){ this.__vburl=String(url||''); this.addEventListener('load',()=>{try{const ct=this.getResponseHeader('content-type')||'';const cd=this.getResponseHeader('content-disposition')||'';if(/excel|spreadsheet|csv|octet-stream/i.test(ct)||/attachment/i.test(cd)||/export|download/i.test(this.__vburl)){let b;if(this.response instanceof Blob)b=this.response;else if(this.response instanceof ArrayBuffer)b=new Blob([this.response],{type:ct});else if(typeof this.responseText==='string'&&this.responseText.length>100)b=new Blob([this.responseText],{type:ct});if(b)sendBlob(b,'export.xlsx');}}catch(e){}});return oopen.call(this,method,url,...rest);};
  }catch(e){}

  connect();
  // SPA mení DOM bez reloadu; informujeme native po významnej zmene.
  let last=''; setInterval(()=>{const x=location.href+'|'+N(document.body?.innerText).slice(0,120); if(x!==last){last=x;send({type:'page',url:location.href,title:document.title,login:isLogin(),bodyLength:(document.body?.innerText||'').length});}},1500);
})();
