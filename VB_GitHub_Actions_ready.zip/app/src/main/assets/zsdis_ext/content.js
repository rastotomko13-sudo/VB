(() => {
  'use strict';
  const N = s => (s || '').toString().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
  let port = null, lastKey = '';

  function isLogin(){
    const b=N(document.body?.innerText);
    return !!document.querySelector('input[type=password]') || (/prihlas/.test(b)&&/hesl/.test(b));
  }
  function visible(e){
    if(!e) return false; const r=e.getBoundingClientRect(); const s=getComputedStyle(e);
    return r.width>1&&r.height>1&&s.display!=='none'&&s.visibility!=='hidden'&&s.opacity!=='0';
  }
  function profileFromText(t){
    t=N(t);
    if(/p_plus|p\s*\+|odber|spotreba|consumption|import/.test(t) && !/dodav|p_minus|p\s*-/.test(t)) return 'import';
    if(/p_minus|p\s*-|dodavka|pretok|prebytok|vyroba|export/.test(t)) return 'export';
    return '';
  }
  function selectedProfile(){
    for(const s of [...document.querySelectorAll('select')].filter(visible)){
      const o=s.options?.[s.selectedIndex]; const p=profileFromText(o?.textContent||''); if(p) return p;
    }
    for(const e of [...document.querySelectorAll('input[type=radio]:checked,input[type=checkbox]:checked')]){
      let txt=(e.value||'')+' '+(e.getAttribute('aria-label')||'');
      if(e.id){const l=document.querySelector(`label[for="${CSS.escape(e.id)}"]`); if(l) txt+=' '+l.textContent;}
      txt+=' '+(e.closest('label')?.textContent||''); const p=profileFromText(txt); if(p) return p;
    }
    for(const e of [...document.querySelectorAll('[role=combobox],mat-select,.mat-select-trigger,.select2-selection')].filter(visible)){
      const p=profileFromText(e.textContent||''); if(p) return p;
    }
    return '';
  }
  function intervalVisible(){
    const b=N(document.body?.innerText);
    if(/intervalove data/.test(b)) return true;
    const inputs=[...document.querySelectorAll('input:not([type=hidden]),textarea')].filter(visible);
    const named=inputs.filter(e=>/datum|date/.test(N((e.name||'')+' '+(e.id||'')+' '+(e.placeholder||'')+' '+(e.getAttribute('aria-label')||''))));
    return inputs.filter(e=>e.type==='date').length>=2 || named.length>=2;
  }
  function sendState(){
    const msg={type:'uiState',url:location.href,title:document.title,login:isLogin(),interval:intervalVisible(),profile:selectedProfile()};
    const key=JSON.stringify(msg); if(key===lastKey) return; lastKey=key;
    try{ browser.runtime.sendMessage(msg); }catch(e){}
    try{ if(port) port.postMessage({type:'page',url:msg.url,title:msg.title,login:msg.login,interval:msg.interval,profile:msg.profile}); }catch(e){}
  }
  function connect(){
    try{
      port=browser.runtime.connectNative('vbspp');
      port.onMessage.addListener(msg=>{
        if(msg?.type==='sync'){
          if(isLogin()) port.postMessage({type:'status',text:'Prihlás sa do ZSDIS. Potom jednorazovo otvor Intervalové dáta; aplikácia si API zapamätá.'});
          else port.postMessage({type:'status',text:'Relácia ZSDIS je prihlásená. Priamy API režim je aktívny.'});
        }
      });
      port.onDisconnect.addListener(()=>{port=null;setTimeout(connect,1000)});
      sendState();
    }catch(e){setTimeout(connect,1200)}
  }
  connect();
  document.addEventListener('change',()=>setTimeout(sendState,50),true);
  document.addEventListener('click',()=>setTimeout(sendState,250),true);
  setInterval(sendState,900);
})();
