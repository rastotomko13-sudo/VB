(() => {
  'use strict';
  const N = s => (s || '').toString().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
  const V = e => { if(!e) return false; const r=e.getBoundingClientRect(); const s=getComputedStyle(e); return r.width>1&&r.height>1&&s.display!=='none'&&s.visibility!=='hidden'&&s.opacity!=='0'; };
  let port = null, command = null, timer = null, passes = 0, exportClicked = false, activeProfile = 'import';
  let objectBlobs = new Map();
  let lastIntClick = 0;
  let lastHomeNavClick = 0;

  function connect(){
    try {
      port = browser.runtime.connectNative('vbspp');
      port.onMessage.addListener(msg => {
        if(!msg || !msg.type) return;
        if(msg.type === 'sync') {
          command = msg; activeProfile = msg.phase || 'import'; passes=0; exportClicked=false; lastIntClick=0; lastHomeNavClick=0;
          status('Automatika ZSDIS: hľadám odberné miesto a intervalové dáta…');
          startLoop();
        }
        if(msg.type === 'ping') send({type:'pong',url:location.href,title:document.title});
      });
      port.onDisconnect.addListener(()=>{port=null; setTimeout(connect,800)});
      send({type:'page',url:location.href,title:document.title,login:isLogin(),bodyLength:(document.body?.innerText||'').length});
    } catch(e) { setTimeout(connect,1000); }
  }
  function send(o){ try{ if(port) port.postMessage(o); }catch(e){} }
  function status(text){ send({type:'status',text,url:location.href}); }
  function isLogin(){ const b=N(document.body?.innerText); return !!document.querySelector('input[type=password]') || (/prihlas/.test(b)&&/hesl/.test(b)); }

  function textOf(e){ return N(e?.innerText || e?.textContent || ''); }
  function interactiveAncestor(el){
    let e=el;
    for(let i=0;e && i<7;i++,e=e.parentElement){
      if(!V(e)) continue;
      const tag=e.tagName;
      const role=N(e.getAttribute?.('role'));
      const cls=N(e.className || '');
      const cur=getComputedStyle(e).cursor;
      if(tag==='BUTTON'||tag==='A'||role==='button'||e.hasAttribute?.('onclick')||e.hasAttribute?.('tabindex')||/btn|button|link|action/.test(cls)||cur==='pointer') return e;
    }
    return el;
  }
  function smartClick(el){
    if(!el || !V(el)) return false;
    let target=interactiveAncestor(el) || el;
    try{
      const r=target.getBoundingClientRect();
      const top=document.elementFromPoint(Math.max(0,Math.min(innerWidth-1,r.left+r.width/2)),Math.max(0,Math.min(innerHeight-1,r.top+r.height/2)));
      if(top && V(top)) target=interactiveAncestor(top)||top;
    }catch(e){}
    try{ target.scrollIntoView({block:'center',inline:'center'}); }catch(e){}
    try{
      for(const t of ['pointerdown','mousedown','pointerup','mouseup']) target.dispatchEvent(new MouseEvent(t,{view:window,bubbles:true,cancelable:true,buttons:1}));
      if(typeof target.click==='function') target.click();
      else target.dispatchEvent(new MouseEvent('click',{view:window,bubbles:true,cancelable:true}));
      return true;
    }catch(e){
      try{ el.click(); return true; }catch(_){ return false; }
    }
  }
  function exactVisible(re, selector='button,a,[role=button],label,span,div,td,p'){
    const all=[...document.querySelectorAll(selector)].filter(V);
    // Najprv najmenší/leaf prvok s presným textom, nie celý rodičovský panel.
    const exact=all.filter(e=>re.test(textOf(e))).sort((a,b)=>(a.children.length-b.children.length)||((a.innerText||'').length-(b.innerText||'').length));
    return exact[0] || null;
  }
  function byText(re, selector='a,button,[role=button],li,span,div,td'){ return [...document.querySelectorAll(selector)].filter(V).find(e=>re.test(textOf(e))); }
  function clickText(re){ const e=exactVisible(re); if(e) return smartClick(e); const f=byText(re); return f?smartClick(f):false; }
  function dateSk(s){ const m=(s||'').match(/(\d{4})-(\d{2})-(\d{2})/); return m?`${m[3]}.${m[2]}.${m[1]}`:s; }
  function setInput(el,val){
    if(!el) return false;
    try {
      const proto = el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto,'value')?.set;
      if(setter) setter.call(el,val); else el.value=val;
      el.dispatchEvent(new Event('input',{bubbles:true})); el.dispatchEvent(new Event('change',{bubbles:true})); el.dispatchEvent(new Event('blur',{bubbles:true}));
      return true;
    } catch(e){ return false; }
  }
  function inputNearLabel(re){
    const labels=[...document.querySelectorAll('label,span,div,p,td')].filter(V).filter(e=>re.test(textOf(e)) && textOf(e).length<40).sort((a,b)=>a.children.length-b.children.length);
    for(const lab of labels){
      const fr=lab.getAttribute?.('for'); if(fr){ const x=document.getElementById(fr); if(x && V(x) && /^(INPUT|TEXTAREA)$/.test(x.tagName)) return x; }
      let p=lab;
      for(let i=0;p && i<4;i++,p=p.parentElement){
        const x=p.querySelector?.('input:not([type=hidden]),textarea'); if(x && V(x)) return x;
        const nx=p.nextElementSibling?.querySelector?.('input:not([type=hidden]),textarea') || (p.nextElementSibling?.matches?.('input,textarea')?p.nextElementSibling:null);
        if(nx && V(nx)) return nx;
      }
    }
    return null;
  }
  function dateControls(){
    const visible=[...document.querySelectorAll('input:not([type=hidden]),textarea')].filter(V);
    const typed=visible.filter(e=>e.type==='date');
    if(typed.length>=2) return [typed[0],typed[1]];
    const od=inputNearLabel(/^datum od\b/), doo=inputNearLabel(/^datum do\b/);
    if(od && doo && od!==doo) return [od,doo];
    const named=visible.filter(e=>/datum|date/.test(N((e.name||'')+' '+(e.id||'')+' '+(e.placeholder||'')+' '+(e.getAttribute('aria-label')||''))));
    return named.length>=2?[named[0],named[1]]:[];
  }
  function intervalFormVisible(){ return dateControls().length>=2; }
  function setDates(){
    if(!command) return false;
    const ds=dateControls(); if(ds.length<2) return false;
    const fmt = ds[0].type==='date' ? (x=>x) : dateSk;
    const a=setInput(ds[0],fmt(command.startDate||''));
    const b=setInput(ds[1],fmt(command.endDate||''));
    return !!(a||b);
  }
  function setProfile(){
    const want=activeProfile;
    const wantRe=want==='import'?/^(p\+|odber|spotreba|import)$/:/^(p-|dodavka|pretok|prebytok|export)$/;
    // Radio/tlačidlá/labely majú prednosť.
    const exact=exactVisible(wantRe,'label,button,a,[role=button],span,div');
    if(exact){
      const inp=exact.querySelector?.('input[type=radio],input[type=checkbox]') || interactiveAncestor(exact)?.querySelector?.('input[type=radio],input[type=checkbox]');
      if(inp && !inp.checked){ inp.click(); inp.dispatchEvent(new Event('change',{bubbles:true})); return true; }
      if(/^(p\+|p-|odber|dodavka|spotreba|pretok|prebytok|import|export)$/.test(textOf(exact))){ smartClick(exact); return true; }
    }
    for(const s of [...document.querySelectorAll('select')].filter(V)){
      const opts=[...s.options]; let idx=-1;
      if(want==='import') idx=opts.findIndex(o=>{const t=N(o.text);return (/p\+/.test(t)||/odber|spotreba|import/.test(t))&&!/dodav|p-/.test(t)});
      else idx=opts.findIndex(o=>{const t=N(o.text);return /p-|dodavka|pretok|prebytok|export/.test(t)});
      if(idx>=0){ if(s.selectedIndex!==idx){s.selectedIndex=idx;s.dispatchEvent(new Event('input',{bubbles:true}));s.dispatchEvent(new Event('change',{bubbles:true}));} return true; }
    }
    const combo=[...document.querySelectorAll('[role=combobox],mat-select,.mat-select-trigger')].find(V);
    if(combo){
      const txt=textOf(combo); const already=want==='import'?(/p\+|odber|spotreba/.test(txt)&&!/dodav/.test(txt)):(/p-|dodavka|pretok|prebytok/.test(txt));
      if(already) return true;
      smartClick(combo);
      setTimeout(()=>{const re=want==='import'?/p\+|odber|spotreba/:/p-|dodavka|pretok|prebytok/; const opt=byText(re,'[role=option],mat-option,.mat-option,li,div,span'); if(opt) smartClick(opt);},350);
      return true;
    }
    return false;
  }

  function meterListLinkAnyVisibility(){
    const all=[...document.querySelectorAll('a[href],button,[role=button]')];
    for(const e of all){
      const t=textOf(e), href=N(e.getAttribute?.('href')||'');
      if(/^odberne miesta$/.test(t) || /odberne[-_\s]*miest/.test(href) || /odberne.*miest/.test(t)) return e;
    }
    return null;
  }
  function menuToggle(){
    const selectors=[
      '.navbar-toggle','.navbar-toggler','.menu-toggle','.hamburger',
      '[class*="navbar-toggle"]','[class*="navbar-toggler"]','[class*="menu-toggle"]','[class*="hamburger"]',
      '[class*="menu-icon"]','[class*="icon-menu"]','[class*="fa-bars"]','[class*="bars"]',
      '[data-toggle="collapse"]','[data-bs-toggle="collapse"]'
    ];
    for(const sel of selectors){
      const e=[...document.querySelectorAll(sel)].find(V); if(e) return interactiveAncestor(e)||e;
    }
    const attrs=[...document.querySelectorAll('button,a,[role=button],div,span')].filter(V);
    for(const e of attrs){
      const a=N((e.getAttribute?.('aria-label')||'')+' '+(e.getAttribute?.('title')||'')+' '+(e.getAttribute?.('data-target')||'')+' '+(e.getAttribute?.('data-bs-target')||''));
      if(/menu|navig|hamburger/.test(a)) return interactiveAncestor(e)||e;
    }
    // Bootstrap hamburger býva tlačidlo s tromi .icon-bar spanmi.
    for(const e of attrs){
      if(e.querySelectorAll?.('.icon-bar').length>=2) return interactiveAncestor(e)||e;
    }
    return null;
  }
  function openMeterListFromHome(){
    // 1) Ak je odkaz v DOM (aj skrytý v menu), preferuj priamo jeho href.
    const link=meterListLinkAnyVisibility();
    if(link){
      const href=link.getAttribute?.('href')||'';
      try{
        if(V(link)) return smartClick(link);
        if(href && href!=='#' && !/^javascript:/i.test(href)){
          const u=new URL(href,location.href); location.href=u.href; return true;
        }
        link.click(); return true;
      }catch(e){}
    }
    // 2) Na úvodnej stránke otvor hamburger/menu. V ďalšom priechode klikneme Odberné miesta.
    const m=menuToggle();
    if(m && Date.now()-lastHomeNavClick>1800){
      lastHomeNavClick=Date.now(); smartClick(m); return true;
    }
    // 3) Posledná poistka: nájdi malé klikateľné tlačidlo vpravo hore pod hlavičkou.
    const cands=[...document.querySelectorAll('button,a,[role=button]')].filter(V).map(e=>({e,r:e.getBoundingClientRect()}))
      .filter(x=>x.r.right>innerWidth*0.72 && x.r.top>70 && x.r.top<260 && x.r.width<120 && x.r.height<100)
      .sort((a,b)=>Math.abs(a.r.top-155)-Math.abs(b.r.top-155));
    if(cands[0] && Date.now()-lastHomeNavClick>1800){ lastHomeNavClick=Date.now(); return smartClick(cands[0].e); }
    return false;
  }

  function chooseFirstMeter(){
    const body=N(document.body?.innerText); if(!/odberne miesta/.test(body)) return false;
    const eic=[...document.querySelectorAll('a,button,[role=button],tr,td,div,span')].filter(V).find(e=>/24z[a-z0-9]{8,}/i.test((e.innerText||'').replace(/\s/g,'')) && (e.innerText||'').length<80);
    return eic?smartClick(eic):false;
  }
  function meterListIntervalButton(){
    return exactVisible(/^(int\.?\s*data|intervalove\s*data)$/,'button,a,[role=button],label,span,div,td,p');
  }
  function exportButton(){ return exactVisible(/^(export|export dat|exportovat)$/,'button,a,[role=button],label,span,div'); }

  function automate(){
    if(!command) return;
    passes++;
    const body=N(document.body?.innerText);
    if(isLogin()) { status('Prihlás sa do ZSDIS. Po prihlásení budem pokračovať automaticky.'); return; }

    // KĽÚČOVÉ: najprv vždy rieš skutočné viditeľné tlačidlo „Int. dáta“.
    // Texty „Dátum od/do“ v detaile EIC už nesmú predstierať intervalový formulár.
    const intBtn=meterListIntervalButton();
    if(intBtn && (Date.now()-lastIntClick>2500)){
      lastIntClick=Date.now();
      status('Našiel som „Int. dáta“ – otváram intervalové dáta…');
      smartClick(intBtn);
      return;
    }

    if(intervalFormVisible()){
      const dateOk=setDates();
      const profileOk=setProfile();
      if(!exportClicked && passes%4===0){
        const show=exactVisible(/^(zobrazit|vyhladat|hladat|potvrdit|nacitat)$/,'button,a,[role=button],span,div');
        if(show){smartClick(show); status('Načítavam intervalové dáta…'); return;}
      }
      const ex=exportButton();
      if(ex && !exportClicked){
        exportClicked=true;
        status(activeProfile==='import'?'Exportujem odber zo siete (P+)…':'Exportujem dodávku do siete (P−)…');
        smartClick(ex);
        setTimeout(()=>{if(exportClicked) exportClicked=false;},12000);
        return;
      }
      status(`Intervalový formulár nájdený (${dateOk?'dátumy OK':'dátumy čakajú'}, ${profileOk?'profil OK':'profil čaká'}), čakám na Export…`);
      return;
    }

    if(/odberne miesta/.test(body)){
      if(chooseFirstMeter()){ status('Vyberám odberné miesto…'); return; }
      status('Som v zozname odberných miest, hľadám tlačidlo „Int. dáta“…');
      return;
    }

    // Po prihlásení ZSDIS skončí na Domov / Úvodná stránka. Menu je na mobile zbalené.
    if(/uvodna stranka|domov/.test(body)){
      if(openMeterListFromHome()){ status('Po prihlásení otváram Odberné miesta…'); return; }
      status('Som na úvodnej stránke ZSDIS, čakám na menu Odberné miesta…');
      return;
    }

    if(clickText(/^odberne miesta$/)){ status('Otváram odberné miesta…'); return; }
    if(openMeterListFromHome()){ status('Hľadám cestu do Odberných miest…'); return; }
    if(passes>45) status('Automatika nenašla ovládanie ZSDIS. Otvorím portál na kontrolu; relácia zostáva prihlásená.');
  }
  function startLoop(){ if(timer) clearInterval(timer); automate(); timer=setInterval(automate,1200); }

  function bufToB64(buf){ let u=new Uint8Array(buf), s=''; const step=0x8000; for(let i=0;i<u.length;i+=step)s+=String.fromCharCode(...u.subarray(i,i+step)); return btoa(s); }
  async function sendBlob(blob,name='export.xlsx'){
    try{
      if(!blob || blob.size<32) return;
      const b64=bufToB64(await blob.arrayBuffer());
      const id='f'+Date.now()+Math.random().toString(16).slice(2); const chunk=180000; const total=Math.ceil(b64.length/chunk);
      send({type:'fileStart',id,name,mime:blob.type||'application/octet-stream',profile:activeProfile,total});
      for(let i=0;i<total;i++) send({type:'fileChunk',id,index:i,data:b64.slice(i*chunk,(i+1)*chunk)});
      send({type:'fileEnd',id});
      status('Export zachytený, spracúvam ho v aplikácii…'); exportClicked=false;
    }catch(e){send({type:'error',text:'Zachytenie exportu zlyhalo: '+e.message});}
  }

  try{
    const origCreate=URL.createObjectURL.bind(URL);
    URL.createObjectURL=function(blob){ const u=origCreate(blob); try{objectBlobs.set(u,blob); setTimeout(()=>objectBlobs.delete(u),60000);}catch(e){} return u; };
    document.addEventListener('click',ev=>{
      const a=ev.target?.closest?.('a'); if(!a) return;
      const text=N(a.innerText||a.textContent), href=a.href||'';
      if(a.download || /export/.test(text)){
        if(href.startsWith('blob:') && objectBlobs.has(href)){ ev.preventDefault(); sendBlob(objectBlobs.get(href),a.download||'export.xlsx'); }
        else if(href && /^https?:/.test(href) && /export|download|excel|xls|csv/i.test(href)){ ev.preventDefault(); fetch(href,{credentials:'include'}).then(r=>r.blob()).then(b=>sendBlob(b,a.download||'export.xlsx')).catch(()=>{}); }
      }
    },true);
  }catch(e){}

  try{
    const ofetch=window.fetch;
    window.fetch=async function(...args){ const r=await ofetch.apply(this,args); try{ const url=String(args[0]?.url||args[0]||r.url||''); const ct=r.headers.get('content-type')||''; const cd=r.headers.get('content-disposition')||''; if(/excel|spreadsheet|csv|octet-stream/i.test(ct)||/attachment/i.test(cd)||/export|download/i.test(url)){ const c=r.clone(); c.blob().then(b=>sendBlob(b,(cd.match(/filename\*?=(?:UTF-8''|\")?([^\";]+)/i)||[])[1]||'export.xlsx')).catch(()=>{}); } }catch(e){} return r; };
  }catch(e){}

  try{
    const oopen=XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open=function(method,url,...rest){ this.__vburl=String(url||''); this.addEventListener('load',()=>{try{const ct=this.getResponseHeader('content-type')||'';const cd=this.getResponseHeader('content-disposition')||'';if(/excel|spreadsheet|csv|octet-stream/i.test(ct)||/attachment/i.test(cd)||/export|download/i.test(this.__vburl)){let b;if(this.response instanceof Blob)b=this.response;else if(this.response instanceof ArrayBuffer)b=new Blob([this.response],{type:ct});else if(typeof this.responseText==='string'&&this.responseText.length>100)b=new Blob([this.responseText],{type:ct});if(b)sendBlob(b,'export.xlsx');}}catch(e){}});return oopen.call(this,method,url,...rest);};
  }catch(e){}

  connect();
  let last=''; setInterval(()=>{const x=location.href+'|'+N(document.body?.innerText).slice(0,120); if(x!==last){last=x;send({type:'page',url:location.href,title:document.title,login:isLogin(),bodyLength:(document.body?.innerText||'').length});}},1500);
})();
