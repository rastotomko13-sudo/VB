(() => {
  'use strict';
  const N = s => (s || '').toString().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
  let port = null, lastKey = '', directRunning = false;

  function send(o){ try{ if(port) port.postMessage(o); }catch(e){} }
  function status(t){ send({type:'status',text:t}); }
  function isLogin(){
    const b=N(document.body?.innerText);
    return !!document.querySelector('input[type=password]') || (/prihlas/.test(b)&&/hesl/.test(b));
  }
  function visible(e){
    if(!e) return false; const r=e.getBoundingClientRect(); const s=getComputedStyle(e);
    return r.width>1&&r.height>1&&s.display!=='none'&&s.visibility!=='hidden'&&s.opacity!=='0';
  }
  function profileFromText(t){
    t=N(t);
    if(/p_plus|p\s*\+|odber|spotreba|consumption|import/.test(t) && !/dodav|p_minus|p\s*-/.test(t)) return 'import';
    if(/p_minus|p\s*-|dodavka|pretok|prebytok|vyroba|export/.test(t)) return 'export';
    return '';
  }
  function selectedProfile(){
    for(const s of [...document.querySelectorAll('select')].filter(visible)){
      const o=s.options?.[s.selectedIndex]; const p=profileFromText(o?.textContent||''); if(p) return p;
    }
    for(const e of [...document.querySelectorAll('input[type=radio]:checked,input[type=checkbox]:checked')]){
      let txt=(e.value||'')+' '+(e.getAttribute('aria-label')||'');
      if(e.id){const l=document.querySelector(`label[for="${CSS.escape(e.id)}"]`); if(l) txt+=' '+l.textContent;}
      txt+=' '+(e.closest('label')?.textContent||''); const p=profileFromText(txt); if(p) return p;
    }
    for(const e of [...document.querySelectorAll('[role=combobox],mat-select,.mat-select-trigger,.select2-selection')].filter(visible)){
      const p=profileFromText(e.textContent||''); if(p) return p;
    }
    return '';
  }
  function intervalVisible(){
    const b=N(document.body?.innerText);
    if(/intervalove data/.test(b)) return true;
    const inputs=[...document.querySelectorAll('input:not([type=hidden]),textarea')].filter(visible);
    const named=inputs.filter(e=>/datum|date/.test(N((e.name||'')+' '+(e.id||'')+' '+(e.placeholder||'')+' '+(e.getAttribute('aria-label')||''))));
    return inputs.filter(e=>e.type==='date').length>=2 || named.length>=2;
  }
  function sendState(){
    const msg={type:'uiState',url:location.href,title:document.title,login:isLogin(),interval:intervalVisible(),profile:selectedProfile()};
    const key=JSON.stringify(msg); if(key===lastKey) return; lastKey=key;
    try{ browser.runtime.sendMessage(msg); }catch(e){}
    send({type:'page',url:msg.url,title:msg.title,login:msg.login,interval:msg.interval,profile:msg.profile});
  }

  function getCookie(name){
    try{
      const m=document.cookie.match(new RegExp('(?:^|;\\s*)'+name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'=([^;]*)'));
      return m ? decodeURIComponent(m[1]) : '';
    }catch(e){ return ''; }
  }
  function pageFetchFn(){
    // Firefox/Gecko MV2: content.fetch() vykoná request ako samotná stránka,
    // teda v správnom first-party kontexte s reláciou Diportalu.
    try{ if(typeof content!=='undefined' && typeof content.fetch==='function') return content.fetch.bind(content); }catch(e){}
    return window.fetch.bind(window);
  }
  async function apiFetch(path,opt={}){
    const url = path.startsWith('http') ? path : new URL(path, location.origin).href;
    const f = pageFetchFn();
    const headers={
      'Accept':'application/json, text/plain, */*',
      'X-Requested-With':'XMLHttpRequest',
      ...(opt.headers||{})
    };
    const xsrf=getCookie('XSRF-TOKEN')||getCookie('xsrf-token');
    const csrf=getCookie('CSRF-TOKEN')||getCookie('csrf-token');
    if(xsrf && !headers['X-XSRF-TOKEN']) headers['X-XSRF-TOKEN']=xsrf;
    if(csrf && !headers['X-CSRF-TOKEN']) headers['X-CSRF-TOKEN']=csrf;
    const options={credentials:'include',cache:'no-store',redirect:'follow',...opt,headers};
    let r;
    try{ r=await f(url,options); }
    catch(e){ throw new Error('NETWORK '+(e?.message||e)); }
    const text=await r.text();
    if(r.status===401||r.status===403||/NOT_AUTHENTICATED|prihlasenie|loginResult"\s*:\s*"FAIL/i.test(text.slice(0,5000))) throw new Error('AUTH');
    if(!r.ok){
      const sample=text.replace(/\s+/g,' ').slice(0,260);
      throw new Error('HTTP '+r.status+' '+url+(sample?' • '+sample:''));
    }
    try{return JSON.parse(text);}catch(e){throw new Error('Neplatná JSON odpoveď z '+url);}
  }

  async function getContext(){
    status('Overujem prihlásenú reláciu ZSDIS…');
    const user=await apiFetch('/portal/api/commons/getUser');
    const d=user?.data||{};
    const assigns=Array.isArray(d.businessPartnerAssignments)?d.businessPartnerAssignments:[];
    const a=assigns.find(x=>Array.isArray(x.businessRoleIds)&&x.businessRoleIds.includes('KZ'))||assigns[0];
    if(!a?.businessPartnerId) throw new Error('AUTH');
    const role=(Array.isArray(a.businessRoleIds)&&a.businessRoleIds.includes('KZ'))?'KZ':(a.businessRoleIds?.[0]||'KZ');
    let source='KOC';
    for(const x of d.customizationParameters||[]) if(x?.key==='intervalData.defaultSource'&&x?.value) source=x.value;

    status('Zisťujem odberné a výrobné miesto…');
    const points=await apiFetch('/portal/api/delivery-points-list/loadDeliveryPoints',{
      method:'POST',
      headers:{'Content-Type':'application/json;charset=UTF-8'},
      body:JSON.stringify({filter:{onlyActive:true,smartMeterEnabled:null,dateFrom:'',dateTo:''},businessPartnerId:String(a.businessPartnerId),businessRoleId:role})
    });
    const list=Array.isArray(points?.data)?points.data:[];
    const active=list.filter(x=>x&&x.active!==false&&x.showIntervalData!==false);
    let cons=active.find(x=>String(x.type||'').toUpperCase()==='CONSUMPTION');
    let supp=active.find(x=>String(x.type||'').toUpperCase()==='SUPPLY');
    if(cons&&!supp&&cons.relatedId) supp=active.find(x=>String(x.deliveryPointId)===String(cons.relatedId));
    if(supp&&!cons&&supp.relatedId) cons=active.find(x=>String(x.deliveryPointId)===String(supp.relatedId));
    if(!cons?.deliveryPointId||!supp?.deliveryPointId) throw new Error('Nenašiel som dvojicu odber + dodávka s intervalovými dátami.');
    return {businessPartnerId:String(a.businessPartnerId),businessRoleId:role,source,consumptionId:String(cons.deliveryPointId),supplyId:String(supp.deliveryPointId)};
  }
  function addDays(iso,n){const d=new Date(iso+'T00:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10)}
  function dateChunks(from,to){
    const out=[]; let a=from;
    while(a<=to){let b=addDays(a,2);if(b>to)b=to;out.push([a,b]);a=addDays(b,1)}
    return out;
  }
  function dailyTotals(j){
    const days=j?.data?.profileData?.dailyIntervalData; if(!Array.isArray(days))return[];
    const out=[];
    for(const day of days){
      const date=String(day?.date||day?.values?.[0]?.dateMeasuredAt||'').slice(0,10); if(!/^\d{4}-\d{2}-\d{2}$/.test(date))continue;
      const vals=Array.isArray(day?.values)?day.values:[];
      let total=0, hourlyCount=0;
      for(const v of vals){const h=Number(v?.hourlyConsumption);if(Number.isFinite(h)){total+=Math.max(0,h);hourlyCount++}}
      if(!hourlyCount){for(const v of vals){const kw=Number(v?.measuredValue);if(Number.isFinite(kw))total+=Math.max(0,kw)*0.25}}
      out.push({date,kwh:Math.round(total*1000000)/1000000});
    }
    return out;
  }
  async function fetchProfile(ctx,deliveryPointId,from,to){
    const body={filter:{deliveryPointId,from,to,profileRole:null,loadProfileRoles:true},businessPartnerId:ctx.businessPartnerId,businessRoleId:ctx.businessRoleId,source:ctx.source};
    return await apiFetch('/portal/api/interval-data/getProfileData',{
      method:'POST',headers:{'Content-Type':'application/json;charset=UTF-8'},body:JSON.stringify(body)
    });
  }
  async function fetchSeries(ctx,id,profile,cmd){
    const all=[]; const chunks=dateChunks(cmd.startDate,cmd.endDate); let n=0;
    for(const [from,to] of chunks){
      n++; status(`${profile==='import'?'Odber':'Dodávka'} zo ZSDIS: ${n}/${chunks.length} (${from} – ${to})`);
      const j=await fetchProfile(ctx,id,from,to); all.push(...dailyTotals(j));
    }
    const byDate=new Map(); for(const r of all)byDate.set(r.date,r);
    send({type:'dailyData',profile,rows:[...byDate.values()].sort((a,b)=>a.date.localeCompare(b.date))});
  }
  async function runDirectSync(cmd){
    if(directRunning)return; directRunning=true;
    try{
      if(isLogin()){send({type:'needLogin',text:'Prihlás sa do ZSDIS. Po prihlásení spusti aktualizáciu znova.'});return;}
      status('Načítavam ZSDIS cez reláciu otvoreného portálu…');
      const ctx=await getContext();
      await fetchSeries(ctx,ctx.consumptionId,'import',cmd);
      await fetchSeries(ctx,ctx.supplyId,'export',cmd);
      send({type:'syncDone'});
    }catch(e){
      if(String(e?.message)==='AUTH') send({type:'needLogin',text:'Relácia ZSDIS vypršala. Prihlás sa znova.'});
      else send({type:'apiError',text:'Priame ZSDIS API zlyhalo: '+(e?.message||e)});
    }finally{directRunning=false;}
  }

  function connect(){
    try{
      port=browser.runtime.connectNative('vbspp');
      port.onMessage.addListener(msg=>{
        if(msg?.type==='sync') runDirectSync(msg);
        if(msg?.type==='startDiag') send({type:'diagStatus',text:'Diagnostika siete je zapnutá.'});
      });
      port.onDisconnect.addListener(()=>{port=null;setTimeout(connect,1000)});
      sendState();
    }catch(e){setTimeout(connect,1200)}
  }
  connect();
  document.addEventListener('change',()=>setTimeout(sendState,50),true);
  document.addEventListener('click',()=>setTimeout(sendState,250),true);
  setInterval(sendState,900);
})();
