(() => {
  'use strict';
  const MAX_CAPTURE = 8 * 1024 * 1024;
  const CHUNK = 120000;
  let nativePort = null;
  let currentCommand = null;
  let directRunning = false;
  const reqMeta = new Map();
  const uiByTab = new Map();

  function N(s){return (s||'').toString().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();}
  function send(o){try{if(nativePort)nativePort.postMessage(o);}catch(e){}}
  function status(t){send({type:'status',text:t});}

  function connectNative(){
    try{
      nativePort=browser.runtime.connectNative('vbspp');
      nativePort.onMessage.addListener(msg=>{if(msg?.type==='sync')handleSync(msg); if(msg?.type==='resetApi')resetApi();});
      nativePort.onDisconnect.addListener(()=>{nativePort=null;setTimeout(connectNative,1200)});
      send({type:'status',text:'ZSDIS API modul pripravený.'});
    }catch(e){setTimeout(connectNative,1500)}
  }

  browser.runtime.onMessage.addListener((msg,sender)=>{
    if(msg?.type==='uiState' && sender?.tab?.id!=null){uiByTab.set(sender.tab.id,msg);}
  });
  browser.tabs?.onRemoved?.addListener(id=>uiByTab.delete(id));

  function requestBodyText(rb){
    try{
      if(!rb) return '';
      if(rb.formData){return new URLSearchParams(Object.entries(rb.formData).flatMap(([k,v])=>(v||[]).map(x=>[k,x]))).toString();}
      if(rb.raw?.length){
        let out=''; for(const r of rb.raw){if(r.bytes)out+=new TextDecoder('utf-8').decode(r.bytes);}
        return out;
      }
    }catch(e){}
    return '';
  }

  function safeHeaders(hs){
    const out={};
    for(const h of hs||[]){
      const k=(h.name||'').toLowerCase();
      if(['accept','content-type','authorization','x-xsrf-token','x-csrf-token','x-requested-with'].includes(k) && h.value) out[h.name]=h.value;
    }
    return out;
  }

  browser.webRequest.onBeforeRequest.addListener(details=>{
    try{
      if(details.tabId<0) return;
      const ui=uiByTab.get(details.tabId)||{};
      const meta={url:details.url,method:details.method||'GET',body:requestBodyText(details.requestBody),tabId:details.tabId,uiProfile:ui.profile||'',interval:!!ui.interval,headers:{}};
      reqMeta.set(details.requestId,meta);
      const filter=browser.webRequest.filterResponseData(details.requestId);
      let parts=[],size=0,truncated=false;
      filter.ondata=ev=>{
        try{filter.write(ev.data);}catch(e){}
        if(truncated)return;
        const u=new Uint8Array(ev.data); if(size+u.length>MAX_CAPTURE){truncated=true;parts=[];return;} parts.push(u.slice()); size+=u.length;
      };
      filter.onstop=()=>{
        try{filter.close();}catch(e){}
        const m=reqMeta.get(details.requestId)||meta; reqMeta.delete(details.requestId);
        if(truncated||!parts.length)return;
        let all=new Uint8Array(size),off=0; for(const p of parts){all.set(p,off);off+=p.length;}
        let text=''; try{text=new TextDecoder('utf-8').decode(all);}catch(e){return;}
        considerCandidate(m,text);
      };
      filter.onerror=()=>{try{filter.disconnect();}catch(e){} reqMeta.delete(details.requestId);};
    }catch(e){}
  },{urls:['https://diportal.sk/*','https://*.diportal.sk/*'],types:['xmlhttprequest']},['blocking','requestBody']);

  browser.webRequest.onBeforeSendHeaders.addListener(details=>{
    const m=reqMeta.get(details.requestId); if(m)m.headers=safeHeaders(details.requestHeaders);
  },{urls:['https://diportal.sk/*','https://*.diportal.sk/*'],types:['xmlhttprequest']},['requestHeaders']);

  function profileFrom(s,fallback=''){
    const t=N(s);
    if(/p_plus|pplus|p\s*\+|odber|spotreba|consumption/.test(t) && !/p_minus|pminus|dodav|pretok|prebytok/.test(t))return'import';
    if(/p_minus|pminus|p\s*-|dodavka|pretok|prebytok|vyroba/.test(t))return'export';
    return fallback||'';
  }
  function candidateScore(m,text){
    const u=N(m.url),t=N(text.slice(0,250000)); let s=0;
    if(/interval|profile|profil|measurement|meran|namer|graph|chart|consumption|energy/.test(u))s+=3;
    const dates=(text.match(/\d{4}-\d{2}-\d{2}|\d{1,2}\.\d{1,2}\.\d{4}/g)||[]).length;
    if(dates>=8)s+=3; else if(dates>=2)s+=1;
    if(/hodnota|value|profil|profile|timestamp|datum|date/.test(t))s+=2;
    if(text.length>1000)s+=1;
    if(m.interval)s+=3;
    return s;
  }
  async function considerCandidate(m,text){
    if(!m||!text||/^\s*</.test(text))return;
    if(candidateScore(m,text)<6)return;
    let profile=profileFrom(m.url+' '+m.body+' '+text.slice(0,12000),m.uiProfile);
    if(!profile && !m.interval)return;
    const both=/p_plus|p\s*\+/.test(N(text)) && /p_minus|p\s*-/.test(N(text));
    if(both)profile='both';
    if(!profile)return;
    const tpl={url:m.url,method:m.method,body:m.body||'',headers:m.headers||{},profile,learnedAt:Date.now()};
    const key=profile==='both'?'apiBoth':profile==='import'?'apiImport':'apiExport';
    await browser.storage.local.set({[key]:tpl});
    send({type:'apiLearned',profile,url:m.url});
    if(profile==='import'||profile==='export')await deriveMate(tpl,profile);
    await maybeReadyAndRun();
  }

  async function deriveMate(tpl,profile){
    const all=(tpl.url+'\n'+tpl.body);
    const rules=profile==='import'
      ? [[/P_PLUS/g,'P_MINUS'],[/p_plus/g,'p_minus'],[/PPLUS/g,'PMINUS'],[/pplus/g,'pminus'],[/P\+/g,'P-'],[/p\+/g,'p-']]
      : [[/P_MINUS/g,'P_PLUS'],[/p_minus/g,'p_plus'],[/PMINUS/g,'PPLUS'],[/pminus/g,'pplus'],[/P-/g,'P+'],[/p-/g,'p+']];
    let changed=false,u=tpl.url,b=tpl.body;
    for(const [re,to] of rules){const nu=u.replace(re,to),nb=b.replace(re,to); if(nu!==u||nb!==b)changed=true;u=nu;b=nb;}
    if(!changed)return;
    const mate={...tpl,url:u,body:b,profile:profile==='import'?'export':'import',derived:true,learnedAt:Date.now()};
    await browser.storage.local.set({[profile==='import'?'apiExport':'apiImport']:mate});
    send({type:'apiLearned',profile:mate.profile,url:mate.url,derived:true});
  }

  async function templates(){return await browser.storage.local.get(['apiBoth','apiImport','apiExport']);}
  async function maybeReadyAndRun(){
    const t=await templates(); const ready=!!t.apiBoth || (!!t.apiImport&&!!t.apiExport);
    if(ready){send({type:'apiReady'}); if(currentCommand&&!directRunning)runDirectSync(currentCommand);}
  }
  async function resetApi(){await browser.storage.local.remove(['apiBoth','apiImport','apiExport']);send({type:'status',text:'Naučené ZSDIS API bolo vymazané.'});}

  function formatLike(old,iso){
    if(!old)return iso; const m=iso.match(/(\d{4})-(\d{2})-(\d{2})/); if(!m)return iso;
    if(/^\d{1,2}\.\d{1,2}\.\d{4}$/.test(old))return `${m[3]}.${m[2]}.${m[1]}`;
    if(/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(old))return `${m[3]}/${m[2]}/${m[1]}`;
    return iso;
  }
  function dateKeyKind(k){
    k=N(k).replace(/[^a-z0-9]/g,'');
    if(/^(datefrom|fromdate|startdate|datumod|oddatum|from|start)$/.test(k))return'from';
    if(/^(dateto|todate|enddate|datumdo|dodatum|to|end)$/.test(k))return'to';
    return'';
  }
  function rewriteObj(x,start,end){
    if(Array.isArray(x)){x.forEach(v=>rewriteObj(v,start,end));return;}
    if(!x||typeof x!=='object')return;
    for(const k of Object.keys(x)){
      const kind=dateKeyKind(k),v=x[k];
      if(kind&&typeof v==='string')x[k]=formatLike(v,kind==='from'?start:end);
      else if(v&&typeof v==='object')rewriteObj(v,start,end);
    }
  }
  function rewriteBody(body,start,end){
    if(!body)return body;
    try{const o=JSON.parse(body);rewriteObj(o,start,end);return JSON.stringify(o);}catch(e){}
    try{
      const p=new URLSearchParams(body);let changed=false;
      for(const [k,v] of [...p.entries()]){const kind=dateKeyKind(k);if(kind){p.set(k,formatLike(v,kind==='from'?start:end));changed=true;}}
      if(changed)return p.toString();
    }catch(e){}
    const ds=[...body.matchAll(/\d{4}-\d{2}-\d{2}|\d{1,2}\.\d{1,2}\.\d{4}/g)];
    if(ds.length){let out=body;const a=ds[0][0],z=ds[ds.length-1][0];out=out.replace(a,formatLike(a,start));if(ds.length>1)out=out.replace(z,formatLike(z,end));return out;}
    return body;
  }
  function rewriteUrl(url,start,end){
    try{
      const u=new URL(url);let changed=false;
      for(const [k,v] of [...u.searchParams.entries()]){const kind=dateKeyKind(k);if(kind){u.searchParams.set(k,formatLike(v,kind==='from'?start:end));changed=true;}}
      if(changed)return u.href;
    }catch(e){}
    const ds=[...url.matchAll(/\d{4}-\d{2}-\d{2}|\d{1,2}\.\d{1,2}\.\d{4}/g)];
    if(ds.length){let out=url,a=ds[0][0],z=ds[ds.length-1][0];out=out.replace(a,formatLike(a,start));if(ds.length>1)out=out.replace(z,formatLike(z,end));return out;}
    return url;
  }

  async function replay(tpl,cmd,profile){
    const url=rewriteUrl(tpl.url,cmd.startDate,cmd.endDate),body=rewriteBody(tpl.body,cmd.startDate,cmd.endDate);
    const headers={...(tpl.headers||{})};
    try{
      const cs=await browser.cookies.getAll({url});
      const xs=cs.find(c=>/xsrf|csrf/i.test(c.name)); if(xs){if(!headers['X-XSRF-TOKEN']&&!headers['x-xsrf-token'])headers['X-XSRF-TOKEN']=decodeURIComponent(xs.value);}
    }catch(e){}
    const opt={method:tpl.method||'GET',headers,credentials:'include',cache:'no-store'};
    if(!/^(GET|HEAD)$/i.test(opt.method)&&body)opt.body=body;
    status(profile==='import'?'Načítavam P+ priamo zo ZSDIS API…':profile==='export'?'Načítavam P− priamo zo ZSDIS API…':'Načítavam intervalové dáta priamo zo ZSDIS API…');
    const r=await fetch(url,opt); const text=await r.text();
    if(r.status===401||r.status===403||/type=["']password|prihlasenie|prihl[aá]s/i.test(text.slice(0,5000)))throw new Error('AUTH');
    if(!r.ok)throw new Error('HTTP '+r.status);
    sendApiText(profile,url,text,r.headers.get('content-type')||'');
  }
  function b64Utf8(s){const bytes=new TextEncoder().encode(s);let bin='';const step=0x8000;for(let i=0;i<bytes.length;i+=step)bin+=String.fromCharCode(...bytes.subarray(i,i+step));return btoa(bin);}
  function sendApiText(profile,url,text,mime){
    const b64=b64Utf8(text),id='a'+Date.now()+Math.random().toString(16).slice(2),total=Math.ceil(b64.length/CHUNK);
    send({type:'apiStart',id,profile,url,mime,total});
    for(let i=0;i<total;i++)send({type:'apiChunk',id,index:i,data:b64.slice(i*CHUNK,(i+1)*CHUNK)});
    send({type:'apiEnd',id});
  }
  async function runDirectSync(cmd){
    if(directRunning)return;directRunning=true;
    try{
      const t=await templates();
      if(t.apiBoth)await replay(t.apiBoth,cmd,'both');
      else{await replay(t.apiImport,cmd,'import');await replay(t.apiExport,cmd,'export');}
      send({type:'syncDone'});
    }catch(e){
      if(String(e?.message)==='AUTH')send({type:'needLogin',text:'Relácia ZSDIS vypršala. Prihlás sa znova; API zostane naučené.'});
      else send({type:'apiError',text:'Priame ZSDIS API zlyhalo: '+(e?.message||e)});
    }finally{directRunning=false;}
  }
  async function handleSync(cmd){
    currentCommand=cmd;
    const t=await templates();
    if(t.apiBoth||(t.apiImport&&t.apiExport)){runDirectSync(cmd);return;}
    send({type:'learnRequired',text:'Jednorazové učenie API: prihlás sa a otvor Odberné miesta → Int. dáta. Zobraz P+ a potom P−. Export už netreba.'});
  }

  connectNative();
})();
