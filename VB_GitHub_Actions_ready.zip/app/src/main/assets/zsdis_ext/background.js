(() => {
  'use strict';
  const MAX_CAPTURE = 8 * 1024 * 1024;
  const CHUNK = 120000;
  let nativePort = null;
  let currentCommand = null;
  let directRunning = false;
  const reqMeta = new Map();
  const uiByTab = new Map();
  let diagMode = false;
  let diagSeq = 0;
  const DIAG_LIMIT = 120;

  function N(s){return (s||'').toString().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();}
  function send(o){try{if(nativePort)nativePort.postMessage(o);}catch(e){}}
  function status(t){send({type:'status',text:t});}

  function connectNative(){
    try{
      nativePort=browser.runtime.connectNative('vbspp');
      nativePort.onMessage.addListener(msg=>{
        if(msg?.type==='sync'){ currentCommand=msg; /* Priamy sync beží v content.js cez content.fetch, aby použil presnú reláciu stránky. */ }
        if(msg?.type==='resetApi') resetApi();
        if(msg?.type==='startDiag'){diagMode=true;diagSeq=0;send({type:'diagStatus',text:'Diagnostika siete je zapnutá. Otvor Intervalové dáta a zobraz údaje.'});}
        if(msg?.type==='stopDiag'){diagMode=false;send({type:'diagStatus',text:'Diagnostika siete bola zastavená.'});}
      });
      nativePort.onDisconnect.addListener(()=>{nativePort=null;setTimeout(connectNative,1200)});
      send({type:'status',text:'ZSDIS API modul pripravený.'});
    }catch(e){setTimeout(connectNative,1500)}
  }

  browser.runtime.onMessage.addListener((msg,sender)=>{
    if(msg?.type==='uiState' && sender?.tab?.id!=null){uiByTab.set(sender.tab.id,msg);}
  });
  browser.tabs?.onRemoved?.addListener(id=>uiByTab.delete(id));



  function redactUrl(raw){
    try{
      const u=new URL(raw);
      for(const k of [...u.searchParams.keys()]) if(/token|auth|session|password|passwd|secret|api.?key|code|state/i.test(k)) u.searchParams.set(k,'[REDACTED]');
      return u.href;
    }catch(e){return String(raw||'').replace(/((?:token|auth|session|password|passwd|secret|api[_-]?key|code|state)[^=&\s]*=)[^&\s]*/ig,'$1[REDACTED]');}
  }
  function redactObject(x){
    if(Array.isArray(x)) return x.map(redactObject);
    if(!x||typeof x!=='object') return x;
    const o={};
    for(const [k,v] of Object.entries(x)) o[k]=/token|auth|session|password|passwd|secret|api.?key|code|state/i.test(k)?'[REDACTED]':redactObject(v);
    return o;
  }
  function redactBody(raw){
    if(!raw)return '';
    try{return JSON.stringify(redactObject(JSON.parse(raw)));}catch(e){}
    try{
      const p=new URLSearchParams(raw), out=new URLSearchParams();
      for(const [k,v] of p.entries()) out.append(k,/token|auth|session|password|passwd|secret|api.?key|code|state/i.test(k)?'[REDACTED]':v);
      if([...p.keys()].length) return out.toString();
    }catch(e){}
    return String(raw).replace(/((?:token|auth|session|password|passwd|secret|api[_-]?key|code|state)[^:=&\s]*\s*[:=]\s*)[^,&\s}\]]+/ig,'$1[REDACTED]');
  }
  function sampleResponse(text){
    let t=String(text||'').slice(0,5000);
    t=t.replace(/(["']?(?:access_?token|refresh_?token|id_?token|session|password|secret)["']?\s*[:=]\s*["'])[^"']+/ig,'$1[REDACTED]');
    return t;
  }
  function diagEmit(m,text){
    if(!diagMode || diagSeq>=DIAG_LIMIT || !m)return;
    const score=candidateScore(m,text||'');
    // Počas intervalovej stránky pošli všetko; inde iba pravdepodobné API/XHR kandidáty.
    const likely=m.interval || score>=2 || /api|interval|profil|profile|meran|measurement|energy|consum|chart|graph|data/i.test(m.url||'');
    if(!likely)return;
    diagSeq++;
    send({
      type:'diagEntry',seq:diagSeq,score,
      method:m.method||'GET',url:redactUrl(m.url),requestBody:redactBody(m.body||''),
      status:m.statusCode||0,mime:m.mime||'',responseLength:String(text||'').length,
      responseSample:sampleResponse(text),pageUrl:redactUrl(m.pageUrl||''),
      pageTitle:m.pageTitle||'',profile:m.uiProfile||'',interval:!!m.interval
    });
    if(score>=6) send({type:'diagStatus',text:'Našiel som silného kandidáta na intervalové API (skóre '+score+'). Ešte nechaj dáta načítať a potom skopíruj diagnostiku.'});
  }

  function requestBodyText(rb){
    try{
      if(!rb) return '';
      if(rb.formData){return new URLSearchParams(Object.entries(rb.formData).flatMap(([k,v])=>(v||[]).map(x=>[k,x]))).toString();}
      if(rb.raw?.length){
        let out=''; for(const r of rb.raw){if(r.bytes)out+=new TextDecoder('utf-8').decode(r.bytes);}
        return out;
      }
    }catch(e){}
    return '';
  }

  function safeHeaders(hs){
    const out={};
    for(const h of hs||[]){
      const k=(h.name||'').toLowerCase();
      if(['accept','content-type','authorization','x-xsrf-token','x-csrf-token','x-requested-with'].includes(k) && h.value) out[h.name]=h.value;
    }
    return out;
  }

  browser.webRequest.onBeforeRequest.addListener(details=>{
    try{
      if(details.tabId<0) return;
      const ui=uiByTab.get(details.tabId); if(!ui) return;
      const meta={url:details.url,method:details.method||'GET',body:requestBodyText(details.requestBody),tabId:details.tabId,uiProfile:ui.profile||'',interval:!!ui.interval,pageUrl:ui.url||'',pageTitle:ui.title||'',headers:{},statusCode:0,mime:''};
      reqMeta.set(details.requestId,meta);
      const filter=browser.webRequest.filterResponseData(details.requestId);
      let parts=[],size=0,truncated=false;
      filter.ondata=ev=>{
        try{filter.write(ev.data);}catch(e){}
        if(truncated)return;
        const u=new Uint8Array(ev.data); if(size+u.length>MAX_CAPTURE){truncated=true;parts=[];return;} parts.push(u.slice()); size+=u.length;
      };
      filter.onstop=()=>{
        try{filter.close();}catch(e){}
        const m=reqMeta.get(details.requestId)||meta; reqMeta.delete(details.requestId);
        if(truncated||!parts.length)return;
        let all=new Uint8Array(size),off=0; for(const p of parts){all.set(p,off);off+=p.length;}
        let text=''; try{text=new TextDecoder('utf-8').decode(all);}catch(e){return;}
        diagEmit(m,text);
        considerCandidate(m,text);
      };
      filter.onerror=()=>{try{filter.disconnect();}catch(e){} reqMeta.delete(details.requestId);};
    }catch(e){}
  },{urls:['https://*/*'],types:['xmlhttprequest']},['blocking','requestBody']);

  browser.webRequest.onBeforeSendHeaders.addListener(details=>{
    const m=reqMeta.get(details.requestId); if(m)m.headers=safeHeaders(details.requestHeaders);
  },{urls:['https://*/*'],types:['xmlhttprequest']},['requestHeaders']);


  browser.webRequest.onHeadersReceived.addListener(details=>{
    const m=reqMeta.get(details.requestId); if(!m)return;
    m.statusCode=details.statusCode||0;
    for(const h of details.responseHeaders||[]){if((h.name||'').toLowerCase()==='content-type'){m.mime=h.value||'';break;}}
  },{urls:['https://*/*'],types:['xmlhttprequest']},['responseHeaders']);

  function profileFrom(s,fallback=''){
    const t=N(s);
    if(/p_plus|pplus|p\s*\+|odber|spotreba|consumption/.test(t) && !/p_minus|pminus|dodav|pretok|prebytok/.test(t))return'import';
    if(/p_minus|pminus|p\s*-|dodavka|pretok|prebytok|vyroba/.test(t))return'export';
    return fallback||'';
  }
  function candidateScore(m,text){
    const u=N(m.url),t=N(text.slice(0,250000)); let s=0;
    if(/interval|profile|profil|measurement|meran|namer|graph|chart|consumption|energy/.test(u))s+=3;
    const dates=(text.match(/\d{4}-\d{2}-\d{2}|\d{1,2}\.\d{1,2}\.\d{4}/g)||[]).length;
    if(dates>=8)s+=3; else if(dates>=2)s+=1;
    if(/hodnota|value|profil|profile|timestamp|datum|date/.test(t))s+=2;
    if(text.length>1000)s+=1;
    if(m.interval)s+=3;
    return s;
  }
  async function considerCandidate(m,text){
    if(!m||!text||/^\s*</.test(text))return;
    if(candidateScore(m,text)<6)return;
    let profile=profileFrom(m.url+' '+m.body+' '+text.slice(0,12000),m.uiProfile);
    if(!profile && !m.interval)return;
    const both=/p_plus|p\s*\+/.test(N(text)) && /p_minus|p\s*-/.test(N(text));
    if(both)profile='both';
    if(!profile)return;
    const tpl={url:m.url,method:m.method,body:m.body||'',headers:m.headers||{},profile,learnedAt:Date.now()};
    const key=profile==='both'?'apiBoth':profile==='import'?'apiImport':'apiExport';
    await browser.storage.local.set({[key]:tpl});
    send({type:'apiLearned',profile,url:m.url});
    if(profile==='import'||profile==='export')await deriveMate(tpl,profile);
    await maybeReadyAndRun();
  }

  async function deriveMate(tpl,profile){
    const all=(tpl.url+'\n'+tpl.body);
    const rules=profile==='import'
      ? [[/P_PLUS/g,'P_MINUS'],[/p_plus/g,'p_minus'],[/PPLUS/g,'PMINUS'],[/pplus/g,'pminus'],[/P\+/g,'P-'],[/p\+/g,'p-']]
      : [[/P_MINUS/g,'P_PLUS'],[/p_minus/g,'p_plus'],[/PMINUS/g,'PPLUS'],[/pminus/g,'pplus'],[/P-/g,'P+'],[/p-/g,'p+']];
    let changed=false,u=tpl.url,b=tpl.body;
    for(const [re,to] of rules){const nu=u.replace(re,to),nb=b.replace(re,to); if(nu!==u||nb!==b)changed=true;u=nu;b=nb;}
    if(!changed)return;
    const mate={...tpl,url:u,body:b,profile:profile==='import'?'export':'import',derived:true,learnedAt:Date.now()};
    await browser.storage.local.set({[profile==='import'?'apiExport':'apiImport']:mate});
    send({type:'apiLearned',profile:mate.profile,url:mate.url,derived:true});
  }

  async function templates(){return await browser.storage.local.get(['apiBoth','apiImport','apiExport']);}
  async function maybeReadyAndRun(){
    const t=await templates(); const ready=!!t.apiBoth || (!!t.apiImport&&!!t.apiExport);
    if(ready){send({type:'apiReady'}); if(currentCommand&&!directRunning)runDirectSync(currentCommand);}
  }
  async function resetApi(){await browser.storage.local.remove(['apiBoth','apiImport','apiExport']);send({type:'status',text:'Naučené ZSDIS API bolo vymazané.'});}

  function formatLike(old,iso){
    if(!old)return iso; const m=iso.match(/(\d{4})-(\d{2})-(\d{2})/); if(!m)return iso;
    if(/^\d{1,2}\.\d{1,2}\.\d{4}$/.test(old))return `${m[3]}.${m[2]}.${m[1]}`;
    if(/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(old))return `${m[3]}/${m[2]}/${m[1]}`;
    return iso;
  }
  function dateKeyKind(k){
    k=N(k).replace(/[^a-z0-9]/g,'');
    if(/^(datefrom|fromdate|startdate|datumod|oddatum|from|start)$/.test(k))return'from';
    if(/^(dateto|todate|enddate|datumdo|dodatum|to|end)$/.test(k))return'to';
    return'';
  }
  function rewriteObj(x,start,end){
    if(Array.isArray(x)){x.forEach(v=>rewriteObj(v,start,end));return;}
    if(!x||typeof x!=='object')return;
    for(const k of Object.keys(x)){
      const kind=dateKeyKind(k),v=x[k];
      if(kind&&typeof v==='string')x[k]=formatLike(v,kind==='from'?start:end);
      else if(v&&typeof v==='object')rewriteObj(v,start,end);
    }
  }
  function rewriteBody(body,start,end){
    if(!body)return body;
    try{const o=JSON.parse(body);rewriteObj(o,start,end);return JSON.stringify(o);}catch(e){}
    try{
      const p=new URLSearchParams(body);let changed=false;
      for(const [k,v] of [...p.entries()]){const kind=dateKeyKind(k);if(kind){p.set(k,formatLike(v,kind==='from'?start:end));changed=true;}}
      if(changed)return p.toString();
    }catch(e){}
    const ds=[...body.matchAll(/\d{4}-\d{2}-\d{2}|\d{1,2}\.\d{1,2}\.\d{4}/g)];
    if(ds.length){let out=body;const a=ds[0][0],z=ds[ds.length-1][0];out=out.replace(a,formatLike(a,start));if(ds.length>1)out=out.replace(z,formatLike(z,end));return out;}
    return body;
  }
  function rewriteUrl(url,start,end){
    try{
      const u=new URL(url);let changed=false;
      for(const [k,v] of [...u.searchParams.entries()]){const kind=dateKeyKind(k);if(kind){u.searchParams.set(k,formatLike(v,kind==='from'?start:end));changed=true;}}
      if(changed)return u.href;
    }catch(e){}
    const ds=[...url.matchAll(/\d{4}-\d{2}-\d{2}|\d{1,2}\.\d{1,2}\.\d{4}/g)];
    if(ds.length){let out=url,a=ds[0][0],z=ds[ds.length-1][0];out=out.replace(a,formatLike(a,start));if(ds.length>1)out=out.replace(z,formatLike(z,end));return out;}
    return url;
  }

  async function apiFetch(url,opt={}){
    const options={credentials:'include',cache:'no-store',...opt};
    options.headers={Accept:'application/json',...(opt.headers||{})};
    const r=await fetch(url,options); const text=await r.text();
    if(r.status===401||r.status===403||/NOT_AUTHENTICATED|prihlasenie|loginResult\"\s*:\s*\"FAIL/i.test(text.slice(0,5000)))throw new Error('AUTH');
    if(!r.ok)throw new Error('HTTP '+r.status+' '+url);
    try{return JSON.parse(text);}catch(e){throw new Error('Neplatná JSON odpoveď z '+url);}
  }
  async function getContext(){
    status('Overujem prihlásenie v ZSDIS…');
    const user=await apiFetch('https://www.diportal.sk/portal/api/commons/getUser');
    const d=user?.data||{};
    const assigns=Array.isArray(d.businessPartnerAssignments)?d.businessPartnerAssignments:[];
    const a=assigns.find(x=>Array.isArray(x.businessRoleIds)&&x.businessRoleIds.includes('KZ'))||assigns[0];
    if(!a?.businessPartnerId)throw new Error('AUTH');
    const role=(Array.isArray(a.businessRoleIds)&&a.businessRoleIds.includes('KZ'))?'KZ':(a.businessRoleIds?.[0]||'KZ');
    let source='KOC';
    for(const x of d.customizationParameters||[])if(x?.key==='intervalData.defaultSource'&&x?.value)source=x.value;
    status('Zisťujem odberné a výrobné miesto…');
    const points=await apiFetch('https://www.diportal.sk/portal/api/delivery-points-list/loadDeliveryPoints',{
      method:'POST',headers:{'Content-Type':'application/json;charset=UTF-8'},
      body:JSON.stringify({filter:{onlyActive:true,smartMeterEnabled:null,dateFrom:'',dateTo:''},businessPartnerId:String(a.businessPartnerId),businessRoleId:role})
    });
    const list=Array.isArray(points?.data)?points.data:[];
    const active=list.filter(x=>x&&x.active!==false&&x.showIntervalData!==false);
    let cons=active.find(x=>String(x.type||'').toUpperCase()==='CONSUMPTION');
    let supp=active.find(x=>String(x.type||'').toUpperCase()==='SUPPLY');
    if(cons&&!supp&&cons.relatedId)supp=active.find(x=>String(x.deliveryPointId)===String(cons.relatedId));
    if(supp&&!cons&&supp.relatedId)cons=active.find(x=>String(x.deliveryPointId)===String(supp.relatedId));
    if(!cons?.deliveryPointId||!supp?.deliveryPointId)throw new Error('Nenašiel som dvojicu odber + dodávka s intervalovými dátami.');
    return {businessPartnerId:String(a.businessPartnerId),businessRoleId:role,source,consumptionId:String(cons.deliveryPointId),supplyId:String(supp.deliveryPointId)};
  }
  function addDays(iso,n){const d=new Date(iso+'T00:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10)}
  function dateChunks(from,to){
    const out=[]; let a=from;
    while(a<=to){let b=addDays(a,2);if(b>to)b=to;out.push([a,b]);a=addDays(b,1)}
    return out;
  }
  function intervalRows(j){
    const days=j?.data?.profileData?.dailyIntervalData; if(!Array.isArray(days))return[];
    const out=[];
    for(const day of days){
      const date=String(day?.date||day?.values?.[0]?.dateMeasuredAt||'').slice(0,10); if(!/^\d{4}-\d{2}-\d{2}$/.test(date))continue;
      const vals=Array.isArray(day?.values)?day.values:[];
      vals.forEach((v,slot)=>{
        const kw=Number(v?.measuredValue); if(!Number.isFinite(kw))return;
        const time=String(v?.measuredAt||'').slice(0,8)||`${String(Math.floor(slot/4)).padStart(2,'0')}:${String((slot%4)*15).padStart(2,'0')}:00`;
        out.push({date,time,slot,kwh:Math.round(Math.max(0,kw)*0.25*1000000)/1000000,kw:Math.round(Math.max(0,kw)*1000000)/1000000,state:String(v?.state||'')});
      });
    }
    return out;
  }
  async function fetchProfile(ctx,deliveryPointId,from,to){
    const body={filter:{deliveryPointId,from,to,profileRole:null,loadProfileRoles:true},businessPartnerId:ctx.businessPartnerId,businessRoleId:ctx.businessRoleId,source:ctx.source};
    return await apiFetch('https://www.diportal.sk/portal/api/interval-data/getProfileData',{
      method:'POST',headers:{'Content-Type':'application/json;charset=UTF-8'},body:JSON.stringify(body)
    });
  }
  async function fetchSeries(ctx,id,profile,cmd){
    const all=[]; const chunks=dateChunks(cmd.startDate,cmd.endDate); let n=0;
    for(const [from,to] of chunks){
      n++; status(`${profile==='import'?'Odber':'Dodávka'} zo ZSDIS: ${n}/${chunks.length} (${from} – ${to})`);
      const j=await fetchProfile(ctx,id,from,to); all.push(...intervalRows(j));
    }
    const bySlot=new Map(); for(const r of all)bySlot.set(`${r.date}|${r.slot}`,r);
    send({type:'intervalData',profile,rows:[...bySlot.values()].sort((a,b)=>a.date.localeCompare(b.date)||a.slot-b.slot)});
  }
  async function runDirectSync(cmd){
    if(directRunning)return; directRunning=true;
    try{
      const ctx=await getContext();
      await fetchSeries(ctx,ctx.consumptionId,'import',cmd);
      await fetchSeries(ctx,ctx.supplyId,'export',cmd);
      send({type:'syncDone'});
    }catch(e){
      if(String(e?.message)==='AUTH')send({type:'needLogin',text:'Prihlás sa do ZSDIS. Po prihlásení sa načítanie spustí znova automaticky.'});
      else send({type:'apiError',text:'Priame ZSDIS API zlyhalo: '+(e?.message||e)});
    }finally{directRunning=false;}
  }
  async function handleSync(cmd){currentCommand=cmd;runDirectSync(cmd);}

  connectNative();
})();
