package sk.rasto.vbspp;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

final class CredentialStore {
    private static final String PREFS = "vb_spp_secure";
    private static final String KEY_ALIAS = "vb_spp_zsdis_login_v1";
    private static final String USER_KEY = "username";
    private static final String PASS_KEY = "password_enc";
    private static final int GCM_TAG_BITS = 128;
    private static final int IV_LEN = 12;

    private final SharedPreferences prefs;

    CredentialStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    synchronized void save(String username, String passwordOrEmptyToKeep) throws Exception {
        String user = username == null ? "" : username.trim();
        SharedPreferences.Editor e = prefs.edit().putString(USER_KEY, user);
        if (passwordOrEmptyToKeep != null && !passwordOrEmptyToKeep.isEmpty()) {
            e.putString(PASS_KEY, encrypt(passwordOrEmptyToKeep));
        }
        e.apply();
    }

    synchronized String getUsername() {
        return prefs.getString(USER_KEY, "");
    }

    synchronized String getPassword() {
        String enc = prefs.getString(PASS_KEY, "");
        if (enc == null || enc.isEmpty()) return "";
        try { return decrypt(enc); } catch (Exception e) { return ""; }
    }

    synchronized boolean hasPassword() {
        return !getPassword().isEmpty();
    }

    synchronized void clear() {
        prefs.edit().remove(USER_KEY).remove(PASS_KEY).apply();
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) {
            return ((KeyStore.SecretKeyEntry) ks.getEntry(KEY_ALIAS, null)).getSecretKey();
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build());
        return kg.generateKey();
    }

    private String encrypt(String value) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
        byte[] iv = c.getIV();
        byte[] ct = c.doFinal(value.getBytes(StandardCharsets.UTF_8));
        byte[] out = new byte[1 + iv.length + ct.length];
        out[0] = (byte) iv.length;
        System.arraycopy(iv, 0, out, 1, iv.length);
        System.arraycopy(ct, 0, out, 1 + iv.length, ct.length);
        return Base64.encodeToString(out, Base64.NO_WRAP);
    }

    private String decrypt(String encoded) throws Exception {
        byte[] all = Base64.decode(encoded, Base64.NO_WRAP);
        if (all.length < 1) return "";
        int ivLen = all[0] & 0xff;
        if (ivLen < 8 || ivLen > 32 || all.length <= 1 + ivLen) return "";
        byte[] iv = new byte[ivLen];
        byte[] ct = new byte[all.length - 1 - ivLen];
        System.arraycopy(all, 1, iv, 0, ivLen);
        System.arraycopy(all, 1 + ivLen, ct, 0, ct.length);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(GCM_TAG_BITS, iv));
        return new String(c.doFinal(ct), StandardCharsets.UTF_8);
    }
}
