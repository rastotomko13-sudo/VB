package sk.rasto.vbspp;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONObject;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;
import org.mozilla.geckoview.WebExtension;

import java.util.HashMap;
import java.util.Map;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String PORTAL_URL = "https://www.diportal.sk/portal/#/verejne/prihlasenie";
    private static final String EXT_LOCATION = "resource://android/assets/zsdis_ext/";
    private static final String EXT_ID = "vbspp-zsdis@local";
    private static final int FILE_CHOOSER = 1001;

    private static GeckoRuntime runtime;
    private FrameLayout root;
    private WebView appView;
    private GeckoView geckoView;
    private GeckoSession geckoSession;
    private WebExtension.Port contentPort;
    private WebExtension.Port backgroundPort;
    private ValueCallback<Uri[]> fileCallback;
    private boolean portalVisible = false;
    private boolean syncInProgress = false;
    private boolean appReady = false;
    private boolean pendingSyncAfterCheck = false;
    private JSONObject pendingCommand;
    private CredentialStore credentialStore;
    private final Handler autoHandler = new Handler(Looper.getMainLooper());
    private final Runnable hourlySync = new Runnable(){
        @Override public void run(){
            if(appReady && !syncInProgress) requestPortalCheck(true);
            autoHandler.postDelayed(this, 60L * 60L * 1000L);
        }
    };
    private final Runnable connectionCheck = new Runnable(){
        @Override public void run(){
            if(appReady && !syncInProgress) requestPortalCheck(false);
            autoHandler.postDelayed(this, 30L * 1000L);
        }
    };

    private static class Transfer {
        String name, mime, profile;
        int total;
        StringBuilder data = new StringBuilder();
    }
    private final Map<String, Transfer> transfers = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = new FrameLayout(this);
        appView = new WebView(this);
        geckoView = new GeckoView(this);
        root.addView(appView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(geckoView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        credentialStore = new CredentialStore(this);
        setupAppView();
        setupGecko();
        geckoView.setVisibility(View.GONE);
        appView.loadUrl("file:///android_asset/index.html");
    }

    private void setupAppView() {
        WebSettings s = appView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        appView.addJavascriptInterface(new Bridge(), "Android");
        appView.setWebViewClient(new WebViewClient());
        appView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
                if(fileCallback!=null) fileCallback.onReceiveValue(null); fileCallback=callback;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","text/csv","text/plain"});
                try{startActivityForResult(i,FILE_CHOOSER);return true;}catch(ActivityNotFoundException e){fileCallback=null;toast("Nenašiel sa správca súborov.");return false;}
            }
        });
    }

    private void setupGecko() {
        if(runtime==null) runtime=GeckoRuntime.create(this);
        GeckoSessionSettings settings=new GeckoSessionSettings.Builder().allowJavascript(true).build();
        geckoSession=new GeckoSession(settings);
        geckoSession.setContentDelegate(new GeckoSession.ContentDelegate(){});
        geckoSession.setProgressDelegate(new GeckoSession.ProgressDelegate(){
            @Override public void onPageStart(GeckoSession session,String url){ if(portalVisible) notifyApp("syncState","ZSDIS: načítavam stránku…"); }
            @Override public void onPageStop(GeckoSession session,boolean success){ if(!success) notifyApp("syncState","ZSDIS stránku sa nepodarilo načítať."); }
        });
        geckoSession.open(runtime);
        geckoView.setSession(geckoSession);
        installHelperExtension();
    }

    private WebExtension.MessageDelegate makePortDelegate(boolean background){
        return new WebExtension.MessageDelegate(){
            @Override public void onConnect(WebExtension.Port port){
                if(background) backgroundPort=port; else contentPort=port;
                port.setDelegate(new WebExtension.PortDelegate(){
                    @Override public void onPortMessage(Object message,WebExtension.Port p){ handleExtensionMessage(message); }
                    @Override public void onDisconnect(WebExtension.Port p){
                        if(p==backgroundPort) backgroundPort=null;
                        if(p==contentPort) contentPort=null;
                    }
                });
                if(pendingCommand!=null){try{port.postMessage(pendingCommand);}catch(Exception ignored){}}
            }
        };
    }

    private void installHelperExtension(){
        runtime.getWebExtensionController().ensureBuiltIn(EXT_LOCATION,EXT_ID).accept(ext->{
            ext.setMessageDelegate(makePortDelegate(true),"vbspp");
            geckoSession.getWebExtensionController().setMessageDelegate(ext,makePortDelegate(false),"vbspp");
            if(syncInProgress) sendSyncCommand();
        },e->{ notifyApp("syncState","Firefox API modul sa nepodarilo pripraviť: "+e.getMessage()); toast("Chyba GeckoView: "+e.getMessage()); });
    }

    private void handleExtensionMessage(Object message){
        if(!(message instanceof JSONObject)) return;
        JSONObject j=(JSONObject)message; String type=j.optString("type","");
        switch(type){
            case "status": notifyApp("syncState",j.optString("text","ZSDIS…")); break;
            case "page":
                if(syncInProgress){
                    if(j.optBoolean("login",false)){
                        if(credentialStore!=null && credentialStore.hasPassword() && !credentialStore.getUsername().isEmpty()){
                            showPortal(false);
                            notifyApp("syncState","Relácia ZSDIS vypršala. Prihlasujem automaticky…");
                            sendSyncCommand();
                        }else{
                            showPortal(true);
                            notifyApp("syncState","Prihlás sa do ZSDIS alebo ulož meno a heslo v Nastaveniach.");
                        }
                    }
                    else if(portalVisible && j.optString("url","").contains("diportal.sk/portal")){
                        notifyApp("syncState","Prihlásenie rozpoznané. Načítavam dáta priamo cez API…");
                        showPortal(false); sendSyncCommand();
                    }
                }
                break;
            case "learnRequired":
                showPortal(true);
                notifyApp("syncState",j.optString("text","Treba sa prihlásiť do ZSDIS."));
                geckoSession.loadUri(PORTAL_URL);
                break;
            case "needLogin":
                boolean haveCreds=credentialStore!=null && credentialStore.hasPassword() && !credentialStore.getUsername().isEmpty();
                showPortal(false);
                notifyPortalState("unauthenticated","Portál dostupný – neprihlásený");
                notifyApp("syncState",haveCreds?"ZSDIS nie je prihlásený. Skúšam automatické prihlásenie…":j.optString("text","ZSDIS nie je prihlásený. Ulož meno a heslo v Nastaveniach alebo sa prihlás ručne."));
                if(haveCreds){
                    try{ geckoSession.loadUri(PORTAL_URL); }catch(Exception ignored){}
                    sendSyncCommand();
                }else{
                    syncInProgress=false;
                    pendingCommand=null;
                }
                break;
            case "portalStatus": {
                String state=j.optString("state","offline");
                String text=j.optString("text","");
                notifyPortalState(state,text);
                if(pendingCommand!=null && "checkConnection".equals(pendingCommand.optString("type",""))) pendingCommand=null;
                if("online".equals(state)){
                    if(pendingSyncAfterCheck && !syncInProgress){
                        pendingSyncAfterCheck=false;
                        startSyncNow();
                    }
                }else if("unauthenticated".equals(state)){
                    boolean saved=credentialStore!=null && credentialStore.hasPassword() && !credentialStore.getUsername().isEmpty();
                    if(pendingSyncAfterCheck && saved && !syncInProgress){
                        pendingSyncAfterCheck=false;
                        startSyncNow();
                    }else if(pendingSyncAfterCheck && !saved){
                        notifyApp("syncState","ZSDIS nie je prihlásený. Aplikáciu môžeš normálne používať; meno a heslo nastav v Nastaveniach.");
                    }
                }else if("offline".equals(state)){
                    notifyApp("syncState","ZSDIS je momentálne nedostupný. Aplikácia zostáva otvorená a pripojenie bude ďalej kontrolovať.");
                }
                break;
            }
            case "diagStatus":
                pendingCommand=null;
                notifyApp("diagState",j.optString("text","Diagnostika ZSDIS…"));
                break;
            case "diagEntry": {
                final String payload=j.toString();
                runOnUiThread(()->appView.evaluateJavascript("window.onNativeDiagEntry&&window.onNativeDiagEntry("+q(payload)+")",null));
                break;
            }
            case "intervalData": {
                final String payload=j.toString();
                runOnUiThread(()->appView.evaluateJavascript("window.onNativeIntervalData&&window.onNativeIntervalData("+q(payload)+")",null));
                break;
            }
            case "dailyData": {
                final String payload=j.toString();
                runOnUiThread(()->appView.evaluateJavascript("window.onNativeDailyData&&window.onNativeDailyData("+q(payload)+")",null));
                break;
            }
            case "apiLearned": {
                String p=j.optString("profile","");
                String txt="import".equals(p)?"P+ API zachytené.":"export".equals(p)?"P− API zachytené.":"ZSDIS API zachytené.";
                notifyApp("syncState",txt+" Pokračujem…");
                toast(txt);
                break;
            }
            case "apiReady": notifyApp("syncState","Interné ZSDIS API je naučené. Načítavam dáta priamo zo servera…"); break;
            case "apiError":
                syncInProgress=false; pendingCommand=null;
                notifyApp("syncState",j.optString("text","Priame ZSDIS API zlyhalo."));
                break;
            case "error":
                syncInProgress=false; pendingCommand=null;
                notifyApp("syncState",j.optString("text","Chyba ZSDIS"));
                break;
            case "apiStart": {
                final String id=j.optString("id"), profile=j.optString("profile",""), url=j.optString("url",""), mime=j.optString("mime","");
                final int total=j.optInt("total",0);
                runOnUiThread(()->appView.evaluateJavascript("window.onNativeApiStart&&window.onNativeApiStart("+q(id)+","+q(profile)+","+q(url)+","+q(mime)+","+total+")",null));
                break;
            }
            case "apiChunk": {
                final String id=j.optString("id"), data=j.optString("data",""); final int index=j.optInt("index",0);
                runOnUiThread(()->appView.evaluateJavascript("window.onNativeApiChunk&&window.onNativeApiChunk("+q(id)+","+index+","+q(data)+")",null));
                break;
            }
            case "apiEnd": {
                final String id=j.optString("id");
                runOnUiThread(()->appView.evaluateJavascript("window.onNativeApiEnd&&window.onNativeApiEnd("+q(id)+")",null));
                break;
            }
            case "syncDone":
                syncInProgress=false; pendingCommand=null; showPortal(false);
                getSharedPreferences("vb_spp",MODE_PRIVATE).edit().putLong("last_sync_ms",System.currentTimeMillis()).apply();
                notifyApp("syncState","ZSDIS aktualizované priamo cez interné API.");
                toast("Virtuálna batéria bola aktualizovaná.");
                break;
            case "fileStart": {
                Transfer t=new Transfer(); t.name=j.optString("name","export.xlsx"); t.mime=j.optString("mime","application/octet-stream"); t.profile=j.optString("profile",""); t.total=j.optInt("total",0); transfers.put(j.optString("id"),t); break;
            }
            case "fileChunk": {
                Transfer t=transfers.get(j.optString("id")); if(t!=null) t.data.append(j.optString("data","")); break;
            }
            case "fileEnd": {
                String id=j.optString("id"); Transfer t=transfers.remove(id); if(t!=null){
                    try{ byte[] bytes=Base64.decode(t.data.toString(),Base64.DEFAULT); onDownloadedBytes(t.name,t.mime,t.profile,bytes); }
                    catch(Exception e){notifyApp("syncState","Export sa nepodarilo dekódovať: "+e.getMessage());}
                } break;
            }
        }
    }

    private void showPortal(boolean show){
        runOnUiThread(()->{portalVisible=show;geckoView.setVisibility(show?View.VISIBLE:View.GONE);if(show)geckoView.bringToFront();else appView.bringToFront();});
    }

    private void requestPortalCheck(boolean syncWhenOnline){
        if(syncWhenOnline) pendingSyncAfterCheck=true;
        notifyPortalState("checking","Kontrolujem ZSDIS…");
        try{
            JSONObject j=new JSONObject(); j.put("type","checkConnection");
            if(contentPort!=null){
                contentPort.postMessage(j);
            }else{
                pendingCommand=j;
                geckoSession.loadUri("https://www.diportal.sk/portal/#/verejne/vitajte");
            }
        }catch(Exception e){
            notifyPortalState("offline","ZSDIS nedostupný");
        }
    }

    private void startSync(){
        if(syncInProgress) return;
        requestPortalCheck(true);
    }

    private void startSyncNow(){
        if(syncInProgress) return;
        syncInProgress=true;
        notifyApp("syncState","Pripojenie ZSDIS je v poriadku. Načítavam odber a dodávku…");
        showPortal(false);
        sendSyncCommand();
        if(contentPort==null){
            try{ geckoSession.loadUri("https://www.diportal.sk/portal/#/verejne/vitajte"); }catch(Exception ignored){}
        }
    }

    private void onAppReady(){
        if(appReady) return;
        appReady=true;
        autoHandler.removeCallbacks(hourlySync);
        autoHandler.removeCallbacks(connectionCheck);
        autoHandler.postDelayed(hourlySync, 60L * 60L * 1000L);
        autoHandler.postDelayed(connectionCheck, 30L * 1000L);
        // Najprv iba skontrolovať portál. Aktualizovať až keď je pripojenie/relácia v poriadku.
        requestPortalCheck(true);
    }

    private void sendSyncCommand(){
        if(!syncInProgress) return;
        try{
            String start=getSharedPreferences("vb_spp",MODE_PRIVATE).getString("period_start","2026-08-01");
            String today=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new java.util.Date());
            JSONObject j=new JSONObject(); j.put("type","sync"); j.put("startDate",start); j.put("endDate",today);
            String user=credentialStore==null?"":credentialStore.getUsername();
            String pass=credentialStore==null?"":credentialStore.getPassword();
            if(!user.isEmpty()) j.put("username",user);
            if(!pass.isEmpty()) j.put("password",pass);
            pendingCommand=j;
            if(backgroundPort!=null) backgroundPort.postMessage(j);
            if(contentPort!=null) contentPort.postMessage(j);
        }catch(Exception ignored){}
    }

    private void startDiagnostics(){
        syncInProgress=false;
        notifyApp("diagState","Spúšťam diagnostiku interných požiadaviek ZSDIS…");
        try{
            JSONObject j=new JSONObject(); j.put("type","startDiag"); pendingCommand=j;
            if(backgroundPort!=null) backgroundPort.postMessage(j);
            if(contentPort!=null) contentPort.postMessage(j);
        }catch(Exception ignored){}
        showPortal(true);
        geckoSession.loadUri(PORTAL_URL);
    }

    private void stopDiagnostics(){
        try{
            JSONObject j=new JSONObject(); j.put("type","stopDiag");
            if(backgroundPort!=null) backgroundPort.postMessage(j);
            if(contentPort!=null) contentPort.postMessage(j);
        }catch(Exception ignored){}
        pendingCommand=null;
    }

    private void onDownloadedBytes(String name,String mime,String profile,byte[] bytes){
        final String b64=Base64.encodeToString(bytes,Base64.NO_WRAP);
        runOnUiThread(()->{
            String js="window.onNativeZsdisFile&&window.onNativeZsdisFile("+q(name)+","+q(mime)+","+q(b64)+","+q(profile)+")";
            appView.evaluateJavascript(js,null);
        });
    }

    private static String q(String s){if(s==null)return "''";return "'"+s.replace("\\","\\\\").replace("'","\\'").replace("\r","").replace("\n","\\n")+"'";}
    private void notifyApp(String fn,String value){runOnUiThread(()->appView.evaluateJavascript("window."+fn+"&&window."+fn+"("+q(value)+")",null));}
    private void notifyPortalState(String state,String text){runOnUiThread(()->appView.evaluateJavascript("window.portalState&&window.portalState("+q(state)+","+q(text)+")",null));}
    private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_LONG).show());}

    public class Bridge{
        @JavascriptInterface public void toast(String s){MainActivity.this.toast(s);}
        @JavascriptInterface public void openUrl(String u){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception ignored){}}
        @JavascriptInterface public void openPortal(){syncInProgress=false; showPortal(true); geckoSession.loadUri(PORTAL_URL);}
        @JavascriptInterface public void syncZsdis(){startSync();}
        @JavascriptInterface public void checkPortal(){requestPortalCheck(false);}
        @JavascriptInterface public void appReady(){MainActivity.this.onAppReady();}
        @JavascriptInterface public String getSavedUsername(){return credentialStore==null?"":credentialStore.getUsername();}
        @JavascriptInterface public boolean hasSavedPassword(){return credentialStore!=null&&credentialStore.hasPassword();}
        @JavascriptInterface public void saveCredentials(String username,String password){
            try{
                credentialStore.save(username,password);
                toast("Prihlásenie ZSDIS bolo bezpečne uložené.");
                pendingSyncAfterCheck=true;
                requestPortalCheck(true);
            }catch(Exception e){toast("Uloženie prihlásenia zlyhalo: "+e.getMessage());}
        }
        @JavascriptInterface public void clearCredentials(){if(credentialStore!=null)credentialStore.clear();toast("Uložené prihlásenie ZSDIS bolo vymazané.");}
        @JavascriptInterface public void startDiagnostics(){MainActivity.this.startDiagnostics();}
        @JavascriptInterface public void stopDiagnostics(){MainActivity.this.stopDiagnostics();}
        @JavascriptInterface public void copyText(String text){
            try{
                ClipboardManager cm=(ClipboardManager)MainActivity.this.getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("ZSDIS diagnostika",text==null?"":text));
                toast("Diagnostika skopírovaná. Vlož ju do chatu.");
            }catch(Exception e){toast("Kopírovanie zlyhalo: "+e.getMessage());}
        }
        @JavascriptInterface public void resetApi(){
            try{JSONObject j=new JSONObject();j.put("type","resetApi");if(backgroundPort!=null)backgroundPort.postMessage(j);}catch(Exception ignored){}
        }
        @JavascriptInterface public void setPeriodStart(String date){if(date!=null)getSharedPreferences("vb_spp",MODE_PRIVATE).edit().putString("period_start",date).apply();}
    }

    @Override public void onBackPressed(){
        if(portalVisible){showPortal(false);return;} super.onBackPressed();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==FILE_CHOOSER&&fileCallback!=null){Uri[] out=null;if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)out=new Uri[]{data.getData()};fileCallback.onReceiveValue(out);fileCallback=null;}
    }

    @Override protected void onResume(){
        super.onResume();
        if(appReady && !syncInProgress){
            long last=getSharedPreferences("vb_spp",MODE_PRIVATE).getLong("last_sync_ms",0L);
            requestPortalCheck(System.currentTimeMillis()-last >= 60L*60L*1000L);
        }
    }

    @Override protected void onDestroy(){
        autoHandler.removeCallbacks(hourlySync);
        autoHandler.removeCallbacks(connectionCheck);
        if(geckoSession!=null) geckoSession.close();
        if(appView!=null) appView.destroy();
        super.onDestroy();
    }
}
