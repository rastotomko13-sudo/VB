package sk.rasto.vbspp;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String PORTAL_URL = "https://www.diportal.sk/portal/index.html";
    private static final int FILE_CHOOSER = 1001;

    private FrameLayout root;
    private WebView appView;
    private WebView portalView;
    private ValueCallback<Uri[]> fileCallback;
    private SharedPreferences prefs;

    private boolean syncInProgress = false;
    private boolean portalVisible = false;
    private int syncPhase = 0; // 0=P+ odber, 1=P- dodavka
    private int automationPasses = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("vb_spp", MODE_PRIVATE);

        root = new FrameLayout(this);
        appView = new WebView(this);
        portalView = new WebView(this);
        root.addView(appView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(portalView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        setupAppView();
        setupPortalView();
        portalView.setVisibility(View.GONE);
        appView.loadUrl("file:///android_asset/index.html");
    }

    private void commonSettings(WebView view) {
        WebSettings s = view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setUserAgentString(s.getUserAgentString().replace("; wv", ""));
    }

    private void setupAppView() {
        commonSettings(appView);
        appView.addJavascriptInterface(new Bridge(), "Android");
        appView.setWebViewClient(new WebViewClient());
        appView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "application/vnd.ms-excel",
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "text/csv", "text/plain"
                });
                try {
                    startActivityForResult(i, FILE_CHOOSER);
                    return true;
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    toast("Nenašiel sa správca súborov.");
                    return false;
                }
            }
        });
    }

    private void setupPortalView() {
        commonSettings(portalView);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(portalView, true);

        portalView.setWebChromeClient(new WebChromeClient());
        portalView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (syncInProgress) scheduleAutomation(900);
            }
        });
        portalView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            if (url == null) return;
            if (url.startsWith("blob:")) {
                portalView.evaluateJavascript(
                    "(async()=>{try{const r=await fetch(" + jsQuote(url) + ");const b=await r.blob();const a=await new Promise((ok,no)=>{const fr=new FileReader();fr.onload=()=>ok(fr.result.split(',')[1]);fr.onerror=no;fr.readAsDataURL(b)});AndroidDownload.sendBlob(a,b.type,'export.xlsx');}catch(e){}})()",
                    null
                );
                return;
            }
            downloadWithSession(url, userAgent, contentDisposition, mimetype);
        });
        portalView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void sendBlob(String b64, String mime, String name) {
                onDownloadedBytes(name, mime, Base64.decode(b64, Base64.DEFAULT));
            }
        }, "AndroidDownload");
    }

    private static String jsQuote(String s) {
        if (s == null) return "''";
        return "'" + s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "") + "'";
    }

    private void showPortal(boolean show) {
        runOnUiThread(() -> {
            portalVisible = show;
            portalView.setVisibility(show ? View.VISIBLE : View.GONE);
            if (show) portalView.bringToFront(); else appView.bringToFront();
        });
    }

    private void startSync(boolean forceShowPortal) {
        syncInProgress = true;
        syncPhase = 0;
        automationPasses = 0;
        notifyApp("syncState", "Pripájam sa k ZSDIS…");
        if (forceShowPortal) showPortal(true); else showPortal(false);
        String current = portalView.getUrl();
        if (current == null || !current.contains("diportal.sk")) portalView.loadUrl(PORTAL_URL);
        else scheduleAutomation(300);
    }

    private void scheduleAutomation(long delayMs) {
        portalView.postDelayed(this::automationPass, delayMs);
    }

    private void automationPass() {
        if (!syncInProgress) return;
        automationPasses++;
        String wanted = syncPhase == 0 ? "IMPORT" : "EXPORT";
        String startDate = prefs.getString("period_start", "2026-08-01");
        String today = new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new java.util.Date());

        String js = "(function(){\n" +
                "const V=e=>{if(!e)return false;const r=e.getBoundingClientRect();const s=getComputedStyle(e);return r.width>1&&r.height>1&&s.display!=='none'&&s.visibility!=='hidden'};\n" +
                "const N=s=>(s||'').toString().normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toLowerCase().replace(/\\s+/g,' ').trim();\n" +
                "const body=N(document.body&&document.body.innerText);\n" +
                "const pw=[...document.querySelectorAll('input[type=password]')].some(V);\n" +
                "if(pw||(/prihlas/.test(body)&&/hesl/.test(body))) return 'LOGIN';\n" +
                "function byText(rx){return [...document.querySelectorAll('a,button,[role=button],li,span,div')].filter(V).find(e=>rx.test(N(e.innerText||e.textContent)))}\n" +
                "function clickRx(rx){const e=byText(rx);if(e){e.click();return true}return false}\n" +
                "// Skus nastavit datumovy interval, ak portal pouziva HTML date inputs.\n" +
                "const ds=[...document.querySelectorAll('input[type=date]')].filter(V);if(ds.length>=2){ds[0].value='" + startDate + "';ds[0].dispatchEvent(new Event('change',{bubbles:true}));ds[1].value='" + today + "';ds[1].dispatchEvent(new Event('change',{bubbles:true}));}\n" +
                "if(!/intervalove data/.test(body)){if(clickRx(/^odberne miesta$/))return 'NAV';if(clickRx(/intervalove data/))return 'NAV';}\n" +
                "if(/intervalove data/.test(body)){\n" +
                " const sels=[...document.querySelectorAll('select')].filter(V);let set=false;\n" +
                " for(const s of sels){const opts=[...s.options];let idx=-1;if('" + wanted + "'==='IMPORT'){idx=opts.findIndex(o=>{const t=N(o.text);return (/p\\+/.test(t)||/cinny vykon/.test(t))&&!/dodav/.test(t)&&!/so stratami/.test(t)});if(idx<0)idx=opts.findIndex(o=>{const t=N(o.text);return (/p\\+/.test(t)||/cinny vykon/.test(t))&&!/dodav/.test(t)})}else{idx=opts.findIndex(o=>{const t=N(o.text);return (/p-/.test(t)||/cinna dodavka/.test(t)||/dodavka/.test(t))&&!/so stratami/.test(t)});if(idx<0)idx=opts.findIndex(o=>{const t=N(o.text);return /p-|cinna dodavka|dodavka/.test(t)})}if(idx>=0&&s.selectedIndex!==idx){s.selectedIndex=idx;s.dispatchEvent(new Event('change',{bubbles:true}));set=true;break}}\n" +
                " if(set)return 'PROFILE';\n" +
                " const ex=byText(/^export$/);if(ex){ex.click();return 'EXPORT_CLICKED'}\n" +
                "}\n" +
                "return 'WAIT';\n" +
                "})()";

        portalView.evaluateJavascript(js, result -> {
            String status = result == null ? "" : result.replace("\"", "");
            if (status.contains("LOGIN")) {
                showPortal(true);
                notifyApp("syncState", "Prihlás sa do ZSDIS. Prihlásenie si aplikácia zapamätá.");
                toast("Prihlás sa do ZSDIS. Potom automaticky pokračujem.");
                return;
            }
            if (status.contains("EXPORT_CLICKED")) {
                notifyApp("syncState", syncPhase == 0 ? "Sťahujem odber zo siete…" : "Sťahujem dodávku do siete…");
                scheduleAutomation(7000);
                return;
            }
            if (automationPasses > 30) {
                showPortal(true);
                notifyApp("syncState", "Automatika potrebuje pomoc: otvor Intervalové dáta a stlač Export. Súbor aplikácia prevezme sama.");
                toast("Otvor v ZSDIS Intervalové dáta a stlač Export. Import prebehne automaticky.");
                return;
            }
            scheduleAutomation(status.contains("PROFILE") ? 1800 : 900);
        });
    }

    private void downloadWithSession(String url, String userAgent, String contentDisposition, String mime) {
        final String cookie = CookieManager.getInstance().getCookie(url);
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("User-Agent", userAgent == null ? portalView.getSettings().getUserAgentString() : userAgent);
                if (cookie != null) c.setRequestProperty("Cookie", cookie);
                c.setRequestProperty("Accept", "*/*");
                String ref = portalView.getUrl();
                if (ref != null) c.setRequestProperty("Referer", ref);
                c.connect();
                try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    byte[] buf = new byte[16384]; int n; long total = 0;
                    while ((n = in.read(buf)) > 0) {
                        total += n; if (total > 20L * 1024 * 1024) throw new Exception("Súbor je príliš veľký");
                        out.write(buf, 0, n);
                    }
                    String name = guessFileName(contentDisposition, url, syncPhase == 0 ? "odber.xlsx" : "dodavka.xlsx");
                    onDownloadedBytes(name, mime, out.toByteArray());
                }
            } catch (Exception e) {
                runOnUiThread(() -> {
                    notifyApp("syncState", "Automatické stiahnutie zlyhalo: " + e.getMessage());
                    showPortal(true);
                    toast("Stiahnutie z ZSDIS zlyhalo. Skús Export priamo v otvorenom portáli.");
                });
            }
        }).start();
    }

    private String guessFileName(String cd, String url, String fallback) {
        if (cd != null) {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("filename\\*?=(?:UTF-8''|\\\")?([^\\\";]+)", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(cd);
            if (m.find()) return Uri.decode(m.group(1).trim());
        }
        try {
            String p = Uri.parse(url).getLastPathSegment();
            if (p != null && p.contains(".")) return p;
        } catch (Exception ignored) {}
        return fallback;
    }

    private void onDownloadedBytes(String name, String mime, byte[] bytes) {
        final String profile = syncPhase == 0 ? "import" : "export";
        final String b64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
        runOnUiThread(() -> {
            String js = "window.onNativeZsdisFile&&window.onNativeZsdisFile(" + jsQuote(name) + "," + jsQuote(mime == null ? "application/octet-stream" : mime) + "," + jsQuote(b64) + "," + jsQuote(profile) + ")";
            appView.evaluateJavascript(js, null);
            prefs.edit().putLong("last_sync_ms", System.currentTimeMillis()).apply();
            if (syncPhase == 0) {
                syncPhase = 1;
                automationPasses = 0;
                notifyApp("syncState", "Odber načítaný, teraz sťahujem dodávku…");
                scheduleAutomation(1500);
            } else {
                syncInProgress = false;
                showPortal(false);
                notifyApp("syncState", "Aktualizované zo ZSDIS");
                toast("ZSDIS dáta boli aktualizované.");
            }
        });
    }

    private void notifyApp(String fn, String text) {
        runOnUiThread(() -> appView.evaluateJavascript("window." + fn + "&&window." + fn + "(" + jsQuote(text) + ")", null));
    }

    private void toast(String text) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, text, Toast.LENGTH_LONG).show());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (portalVisible) {
            if (portalView.canGoBack()) portalView.goBack(); else showPortal(false);
            return;
        }
        if (appView.canGoBack()) appView.goBack(); else super.onBackPressed();
    }

    public class Bridge {
        @JavascriptInterface public void openUrl(String url) {
            runOnUiThread(() -> { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { toast("Odkaz sa nepodarilo otvoriť."); } });
        }
        @JavascriptInterface public void toast(String text) { MainActivity.this.toast(text); }
        @JavascriptInterface public void openPortal() { showPortal(true); if (portalView.getUrl() == null) portalView.loadUrl(PORTAL_URL); }
        @JavascriptInterface public void syncZsdis() { startSync(false); }
        @JavascriptInterface public void savePeriodStart(String date) { prefs.edit().putString("period_start", date).apply(); }
        @JavascriptInterface public long getLastSyncMs() { return prefs.getLong("last_sync_ms", 0); }
    }
}
