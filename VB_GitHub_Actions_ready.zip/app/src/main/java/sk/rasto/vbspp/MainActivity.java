package sk.rasto.vbspp;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONObject;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;
import org.mozilla.geckoview.WebExtension;

import java.util.HashMap;
import java.util.Map;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String PORTAL_URL = "https://www.diportal.sk/portal/#/verejne/prihlasenie";
    private static final String EXT_LOCATION = "resource://android/assets/zsdis_ext/";
    private static final String EXT_ID = "vbspp-zsdis@local";
    private static final int FILE_CHOOSER = 1001;

    private static GeckoRuntime runtime;
    private FrameLayout root;
    private WebView appView;
    private GeckoView geckoView;
    private GeckoSession geckoSession;
    private WebExtension.Port automationPort;
    private ValueCallback<Uri[]> fileCallback;
    private boolean portalVisible = false;
    private boolean syncInProgress = false;
    private int syncPhase = 0;
    private JSONObject pendingCommand;

    private static class Transfer {
        String name, mime, profile;
        int total;
        StringBuilder data = new StringBuilder();
    }
    private final Map<String, Transfer> transfers = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = new FrameLayout(this);
        appView = new WebView(this);
        geckoView = new GeckoView(this);
        root.addView(appView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(geckoView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        setupAppView();
        setupGecko();
        geckoView.setVisibility(View.GONE);
        appView.loadUrl("file:///android_asset/index.html");
    }

    private void setupAppView() {
        WebSettings s = appView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        appView.addJavascriptInterface(new Bridge(), "Android");
        appView.setWebViewClient(new WebViewClient());
        appView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
                if(fileCallback!=null) fileCallback.onReceiveValue(null); fileCallback=callback;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","text/csv","text/plain"});
                try{startActivityForResult(i,FILE_CHOOSER);return true;}catch(ActivityNotFoundException e){fileCallback=null;toast("Nenašiel sa správca súborov.");return false;}
            }
        });
    }

    private void setupGecko() {
        if(runtime==null) runtime=GeckoRuntime.create(this);
        GeckoSessionSettings settings=new GeckoSessionSettings.Builder().allowJavascript(true).build();
        geckoSession=new GeckoSession(settings);
        geckoSession.setContentDelegate(new GeckoSession.ContentDelegate(){});
        geckoSession.setProgressDelegate(new GeckoSession.ProgressDelegate(){
            @Override public void onPageStart(GeckoSession session,String url){ notifyApp("syncState","ZSDIS: načítavam stránku…"); }
            @Override public void onPageStop(GeckoSession session,boolean success){ if(!success) notifyApp("syncState","ZSDIS stránku sa nepodarilo načítať."); }
        });
        geckoSession.setNavigationDelegate(new GeckoSession.NavigationDelegate(){
            @Override public void onLocationChange(GeckoSession session,String url,java.util.List<GeckoSession.PermissionDelegate.ContentPermission> perms,Boolean gesture){
                if(url!=null && url.contains("diportal.sk") && syncInProgress) sendSyncCommand();
            }
        });
        geckoSession.open(runtime);
        geckoView.setSession(geckoSession);
        installHelperExtension();
    }

    private void installHelperExtension(){
        runtime.getWebExtensionController().ensureBuiltIn(EXT_LOCATION,EXT_ID).accept(ext->{
            WebExtension.MessageDelegate md=new WebExtension.MessageDelegate(){
                @Override public void onConnect(WebExtension.Port port){
                    automationPort=port;
                    port.setDelegate(new WebExtension.PortDelegate(){
                        @Override public void onPortMessage(Object message,WebExtension.Port p){ handleExtensionMessage(message); }
                        @Override public void onDisconnect(WebExtension.Port p){ if(p==automationPort) automationPort=null; }
                    });
                    if(pendingCommand!=null) { try{automationPort.postMessage(pendingCommand);}catch(Exception ignored){} }
                }
            };
            geckoSession.getWebExtensionController().setMessageDelegate(ext,md,"vbspp");
            if(syncInProgress) sendSyncCommand();
        },e->{ notifyApp("syncState","Firefox modul sa nepodarilo pripraviť: "+e.getMessage()); toast("Chyba GeckoView: "+e.getMessage()); });
    }

    private void handleExtensionMessage(Object message){
        if(!(message instanceof JSONObject)) return;
        JSONObject j=(JSONObject)message; String type=j.optString("type","");
        switch(type){
            case "status": notifyApp("syncState",j.optString("text","ZSDIS…")); break;
            case "page":
                if(j.optBoolean("login",false)){ showPortal(true); notifyApp("syncState","Prihlás sa do ZSDIS. Po prihlásení budem pokračovať automaticky."); }
                break;
            case "error": notifyApp("syncState",j.optString("text","Chyba ZSDIS")); break;
            case "fileStart": {
                Transfer t=new Transfer(); t.name=j.optString("name","export.xlsx"); t.mime=j.optString("mime","application/octet-stream"); t.profile=j.optString("profile",syncPhase==0?"import":"export"); t.total=j.optInt("total",0); transfers.put(j.optString("id"),t); break;
            }
            case "fileChunk": {
                Transfer t=transfers.get(j.optString("id")); if(t!=null) t.data.append(j.optString("data","")); break;
            }
            case "fileEnd": {
                String id=j.optString("id"); Transfer t=transfers.remove(id); if(t!=null){
                    try{ byte[] bytes=Base64.decode(t.data.toString(),Base64.DEFAULT); onDownloadedBytes(t.name,t.mime,t.profile,bytes); }
                    catch(Exception e){notifyApp("syncState","Export sa nepodarilo dekódovať: "+e.getMessage());}
                } break;
            }
        }
    }

    private void showPortal(boolean show){
        runOnUiThread(()->{portalVisible=show;geckoView.setVisibility(show?View.VISIBLE:View.GONE);if(show)geckoView.bringToFront();else appView.bringToFront();});
    }

    private void startSync(boolean show){
        syncInProgress=true; syncPhase=0; notifyApp("syncState","Pripájam sa k ZSDIS cez Firefox engine…");
        showPortal(show);
        sendSyncCommand();
        geckoSession.loadUri(PORTAL_URL);
    }

    private void sendSyncCommand(){
        if(!syncInProgress) return;
        try{
            String start=getSharedPreferences("vb_spp",MODE_PRIVATE).getString("period_start","2026-08-01");
            String today=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new java.util.Date());
            JSONObject j=new JSONObject(); j.put("type","sync");j.put("phase",syncPhase==0?"import":"export");j.put("startDate",start);j.put("endDate",today);
            pendingCommand=j;
            if(automationPort!=null) automationPort.postMessage(j);
        }catch(Exception ignored){}
    }

    private void onDownloadedBytes(String name,String mime,String profile,byte[] bytes){
        final String b64=Base64.encodeToString(bytes,Base64.NO_WRAP);
        runOnUiThread(()->{
            String js="window.onNativeZsdisFile&&window.onNativeZsdisFile("+q(name)+","+q(mime)+","+q(b64)+","+q(profile)+")";
            appView.evaluateJavascript(js,null);
            if("import".equals(profile)){
                syncPhase=1; notifyApp("syncState","Odber načítaný. Teraz sťahujem dodávku do siete…"); sendSyncCommand();
            }else{
                syncInProgress=false; pendingCommand=null; notifyApp("syncState","ZSDIS aktualizované. Odber aj dodávka sú načítané."); showPortal(false); toast("Virtuálna batéria bola aktualizovaná.");
            }
        });
    }

    private static String q(String s){if(s==null)return "''";return "'"+s.replace("\\","\\\\").replace("'","\\'").replace("\n","")+"'";}
    private void notifyApp(String fn,String value){runOnUiThread(()->appView.evaluateJavascript("window."+fn+"&&window."+fn+"("+q(value)+")",null));}
    private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_LONG).show());}

    public class Bridge{
        @JavascriptInterface public void toast(String s){MainActivity.this.toast(s);}
        @JavascriptInterface public void openUrl(String u){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception ignored){}}
        @JavascriptInterface public void openPortal(){syncInProgress=false; showPortal(true); geckoSession.loadUri(PORTAL_URL);}
        @JavascriptInterface public void syncZsdis(){startSync(false);}
        @JavascriptInterface public void setPeriodStart(String date){if(date!=null)getSharedPreferences("vb_spp",MODE_PRIVATE).edit().putString("period_start",date).apply();}
    }

    @Override public void onBackPressed(){
        if(portalVisible){showPortal(false);return;} super.onBackPressed();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==FILE_CHOOSER&&fileCallback!=null){Uri[] out=null;if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)out=new Uri[]{data.getData()};fileCallback.onReceiveValue(out);fileCallback=null;}
    }

    @Override protected void onDestroy(){
        if(geckoSession!=null) geckoSession.close();
        if(appView!=null) appView.destroy();
        super.onDestroy();
    }
}
