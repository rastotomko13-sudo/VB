package sk.goodwe.live;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private static final int UNIT_ID = 0;
    private static final int DEFAULT_PORT = 502;
    private static final int REQUEST_NEARBY_WIFI_DEVICES = 1001;

    private WebView webView;
    private ScheduledExecutorService poller;
    private volatile boolean connected;
    private volatile int transactionId = 1;
    private String pendingHost;
    private int pendingPort = DEFAULT_PORT;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF07131B);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.addJavascriptInterface(new GoodWeBridge(), "GoodWe");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void beginConnection(String host, int port) {
        pendingHost = host.trim();
        pendingPort = port;
        getPreferences(MODE_PRIVATE).edit()
                .putString("ip", pendingHost).putInt("port", pendingPort).apply();
        runOnUiThread(() -> {
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.NEARBY_WIFI_DEVICES},
                        REQUEST_NEARBY_WIFI_DEVICES);
            } else {
                startPolling();
            }
        });
    }

    private void startPolling() {
        stopPolling();
        connected = true;
        sendToPage("{\"state\":\"connecting\"}");
        final String host = pendingHost;
        final int port = pendingPort;
        poller = Executors.newSingleThreadScheduledExecutor();
        poller.scheduleWithFixedDelay(() -> poll(host, port), 0, 2, TimeUnit.SECONDS);
    }

    private void poll(String host, int port) {
        try {
            int[] pvRegs = readHoldingRegisters(host, port, 35105, 6);
            long pv = Integer.toUnsignedLong(toInt32(pvRegs[0], pvRegs[1]))
                    + Integer.toUnsignedLong(toInt32(pvRegs[4], pvRegs[5]));

            // GoodWe ET house load calculation without a battery: PV power - active power.
            int[] activeRegs = readHoldingRegisters(host, port, 35140, 2);
            int activePower = toInt32(activeRegs[0], activeRegs[1]);
            long house = Math.max(0L, pv - (long) activePower);

            int[] meterRegs = readHoldingRegisters(host, port, 36025, 2);
            int grid = toInt32(meterRegs[0], meterRegs[1]);

            JSONObject result = new JSONObject();
            result.put("state", "connected");
            result.put("pv", pv);
            result.put("house", house);
            result.put("grid", grid);
            sendToPage(result.toString());
        } catch (Exception e) {
            JSONObject result = new JSONObject();
            try {
                result.put("state", "error");
                result.put("error", e.toString());
            } catch (Exception ignored) { }
            sendToPage(result.toString());
        }
    }

    private void sendToPage(String json) {
        if (webView == null) return;
        String script = "window.renderGoodWe && window.renderGoodWe(" + json + ");";
        webView.post(() -> webView.evaluateJavascript(script, null));
    }

    private int[] readHoldingRegisters(String host, int port, int start, int count) throws IOException {
        int tx = (transactionId++ & 0xFFFF);
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(host, port), 3000);
            socket.setSoTimeout(3000);
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            DataInputStream in = new DataInputStream(socket.getInputStream());
            out.writeShort(tx);
            out.writeShort(0);
            out.writeShort(6);
            out.writeByte(UNIT_ID);
            out.writeByte(3);
            out.writeShort(start);
            out.writeShort(count);
            out.flush();

            int responseTx = in.readUnsignedShort();
            int protocol = in.readUnsignedShort();
            int length = in.readUnsignedShort();
            int unit = in.readUnsignedByte();
            if (responseTx != tx || protocol != 0 || unit != UNIT_ID || length < 3) {
                throw new IOException("Neplatná odpoveď meniča (TCP hlavička)");
            }
            int function = in.readUnsignedByte();
            if ((function & 0x80) != 0) {
                int code = in.readUnsignedByte();
                throw new IOException("GoodWe odmietol register " + start + " (Modbus kód " + code + ")");
            }
            int byteCount = in.readUnsignedByte();
            if (function != 3 || byteCount != count * 2) {
                throw new IOException("Neočakávaná Modbus odpoveď pre register " + start);
            }
            int[] regs = new int[count];
            for (int i = 0; i < count; i++) regs[i] = in.readUnsignedShort();
            return regs;
        }
    }

    private int toInt32(int high, int low) {
        return (high << 16) | low;
    }

    private void stopPolling() {
        connected = false;
        if (poller != null) {
            poller.shutdownNow();
            poller = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_NEARBY_WIFI_DEVICES) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startPolling();
            } else {
                sendToPage("{\"state\":\"error\",\"error\":\"Povoľ Zariadenia v okolí pre prístup k GoodWe.\"}");
            }
        }
    }

    @Override
    protected void onDestroy() {
        stopPolling();
        if (webView != null) {
            webView.removeJavascriptInterface("GoodWe");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private class GoodWeBridge {
        @JavascriptInterface
        public void connect(String host, String portText) {
            try {
                int port = Integer.parseInt(portText.trim());
                if (host == null || host.trim().isEmpty() || port < 1 || port > 65535) {
                    sendToPage("{\"state\":\"error\",\"error\":\"Skontroluj IP adresu a port.\"}");
                    return;
                }
                beginConnection(host, port);
            } catch (NumberFormatException e) {
                sendToPage("{\"state\":\"error\",\"error\":\"Port musí byť číslo od 1 do 65535.\"}");
            }
        }

        @JavascriptInterface
        public void disconnect() {
            runOnUiThread(() -> {
                stopPolling();
                sendToPage("{\"state\":\"disconnected\"}");
            });
        }

        @JavascriptInterface
        public String settings() {
            return getPreferences(MODE_PRIVATE).getString("ip", "192.168.1.138") + "|"
                    + getPreferences(MODE_PRIVATE).getInt("port", DEFAULT_PORT);
        }
    }
}
