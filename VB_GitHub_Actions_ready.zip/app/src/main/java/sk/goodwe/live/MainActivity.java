package sk.goodwe.live;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(10, 19, 27);
    private static final int PANEL = Color.rgb(19, 34, 45);
    private static final int MUTED = Color.rgb(171, 188, 199);
    private static final int GREEN = Color.rgb(73, 220, 169);
    private static final int AMBER = Color.rgb(255, 193, 105);
    private static final int BLUE = Color.rgb(139, 190, 255);
    // GoodWe's Modbus/TCP interface uses comm_addr 0; 247 is common for its UDP protocol.
    private static final int UNIT_ID = 0;
    private static final int MODBUS_PORT = 502;
    private static final int POLL_SECONDS = 2;

    private EditText ipInput;
    private EditText portInput;
    private TextView statusView;
    private TextView pvView;
    private TextView houseView;
    private TextView gridView;
    private Button connectButton;
    private ScheduledExecutorService executor;
    private volatile boolean connected = false;
    private volatile int transactionId = 1;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildScreen();
        ipInput.setText(getPreferences(MODE_PRIVATE).getString("ip", ""));
        portInput.setText(String.valueOf(getPreferences(MODE_PRIVATE).getInt("port", MODBUS_PORT)));
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(24));
        scroll.addView(root);

        TextView title = text("GoodWe Live", 26, Color.WHITE, true);
        root.addView(title, params(-1, dp(40)));
        TextView subtitle = text("Okamžitý výkon priamo z meniča", 14, MUTED, false);
        root.addView(subtitle, params(-1, dp(30)));

        statusView = text("Odpojené", 14, MUTED, false);
        statusView.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(statusView, params(-1, dp(30)));

        pvView = addPowerCard(root, "OKAMŽITÁ VÝROBA FV", "— W", GREEN);
        houseView = addPowerCard(root, "OKAMŽITÁ SPOTREBA DOMU", "— W", AMBER);

        gridView = text("Tok do / zo siete: —", 15, BLUE, true);
        gridView.setGravity(Gravity.CENTER_VERTICAL);
        gridView.setPadding(dp(14), 0, dp(14), 0);
        gridView.setBackground(rounded(PANEL, dp(15)));
        LinearLayout.LayoutParams gridParams = params(-1, dp(54));
        gridParams.topMargin = dp(12);
        root.addView(gridView, gridParams);

        TextView device = text("GoodWe GW10KN-ET PLUS+  •  Modbus TCP", 12, MUTED, false);
        device.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams deviceParams = params(-1, dp(40));
        deviceParams.topMargin = dp(8);
        root.addView(device, deviceParams);

        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.HORIZONTAL);
        fields.setGravity(Gravity.CENTER_VERTICAL);
        fields.setPadding(0, dp(8), 0, dp(8));
        ipInput = new EditText(this);
        ipInput.setSingleLine(true);
        ipInput.setTextColor(Color.WHITE);
        ipInput.setHintTextColor(MUTED);
        ipInput.setHint("IP GoodWe");
        ipInput.setTextSize(16);
        ipInput.setInputType(UrlInputType());
        ipInput.setPadding(dp(12), 0, dp(12), 0);
        ipInput.setBackground(rounded(PANEL, dp(12)));
        fields.addView(ipInput, new LinearLayout.LayoutParams(0, dp(50), 1));

        portInput = new EditText(this);
        portInput.setSingleLine(true);
        portInput.setTextColor(Color.WHITE);
        portInput.setHintTextColor(MUTED);
        portInput.setHint("Port");
        portInput.setTextSize(16);
        portInput.setInputType(2);
        portInput.setPadding(dp(10), 0, dp(10), 0);
        portInput.setBackground(rounded(PANEL, dp(12)));
        LinearLayout.LayoutParams portParams = new LinearLayout.LayoutParams(dp(86), dp(50));
        portParams.leftMargin = dp(8);
        fields.addView(portInput, portParams);
        LinearLayout.LayoutParams fieldsParams = params(-1, dp(66));
        fieldsParams.topMargin = dp(8);
        root.addView(fields, fieldsParams);

        connectButton = new Button(this);
        connectButton.setText("PRIPOJIŤ");
        connectButton.setTextColor(Color.WHITE);
        connectButton.setTextSize(15);
        connectButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        connectButton.setBackground(rounded(Color.rgb(25, 142, 106), dp(14)));
        connectButton.setOnClickListener(v -> toggleConnection());
        LinearLayout.LayoutParams buttonParams = params(-1, dp(52));
        buttonParams.topMargin = dp(6);
        root.addView(connectButton, buttonParams);

        TextView help = text("Telefón a menič musia byť na rovnakej domácej Wi‑Fi.\nČítanie každé 2 sekundy • iba monitorovanie",
                12, MUTED, false);
        help.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams helpParams = params(-1, dp(58));
        helpParams.topMargin = dp(12);
        root.addView(help, helpParams);

        setContentView(scroll);
    }

    private int UrlInputType() {
        return 3; // TYPE_CLASS_PHONE keeps the IPv4 keyboard convenient.
    }

    private TextView addPowerCard(LinearLayout root, String label, String initial, int valueColor) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(19), dp(15), dp(19), dp(15));
        card.setBackground(rounded(PANEL, dp(19)));
        TextView caption = text(label, 12, MUTED, true);
        card.addView(caption, params(-1, dp(28)));
        TextView value = text(initial, 35, valueColor, true);
        card.addView(value, params(-1, dp(60)));
        LinearLayout.LayoutParams cardParams = params(-1, dp(130));
        cardParams.topMargin = dp(12);
        root.addView(card, cardParams);
        return value;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }

    private LinearLayout.LayoutParams params(int width, int height) {
        return new LinearLayout.LayoutParams(width, height);
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(radius);
        return shape;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toggleConnection() {
        if (connected) {
            stopPolling();
            statusView.setText("Odpojené");
            connectButton.setText("PRIPOJIŤ");
            return;
        }
        String host = ipInput.getText().toString().trim();
        int port;
        try {
            port = Integer.parseInt(portInput.getText().toString().trim());
            if (host.isEmpty() || port < 1 || port > 65535) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            statusView.setText("Skontroluj IP adresu a port");
            return;
        }
        getPreferences(MODE_PRIVATE).edit().putString("ip", host).putInt("port", port).apply();
        connected = true;
        connectButton.setText("ODPOJIŤ");
        statusView.setText("Pripájam k meniču…");
        final String selectedHost = host;
        final int selectedPort = port;
        executor = Executors.newSingleThreadScheduledExecutor();
        executor.scheduleWithFixedDelay(() -> poll(selectedHost, selectedPort), 0, POLL_SECONDS, TimeUnit.SECONDS);
    }

    private void poll(String host, int port) {
        try {
            int[] pvRegs = readHoldingRegisters(host, port, 35105, 6);
            int[] gridRegs = readHoldingRegisters(host, port, 36025, 2);
            long pv = Integer.toUnsignedLong(toInt32(pvRegs[0], pvRegs[1]))
                    + Integer.toUnsignedLong(toInt32(pvRegs[4], pvRegs[5]));
            int grid = toInt32(gridRegs[0], gridRegs[1]);
            // This site has no battery: home load = PV production - signed grid power.
            long house = Math.max(0L, pv - (long) grid);
            runOnUiThread(() -> showValues(pv, house, grid));
        } catch (Exception e) {
            String message = e.getMessage() == null ? "Skontroluj Wi‑Fi a Modbus TCP" : e.getMessage();
            runOnUiThread(() -> {
                if (connected) statusView.setText("Bez spojenia — skúšam znova");
                gridView.setText(message.length() > 60 ? message.substring(0, 60) : message);
            });
        }
    }

    private void showValues(long pv, long house, int grid) {
        if (!connected) return;
        pvView.setText(formatWatts(pv));
        houseView.setText(formatWatts(house));
        String flow = grid < 0
                ? "Prebytok do siete: " + formatWatts(Math.abs((long) grid))
                : "Odber zo siete: " + formatWatts(grid);
        gridView.setText(flow);
        statusView.setText("Pripojené • aktualizované " + new java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new java.util.Date()));
    }

    private String formatWatts(long watts) {
        return NumberFormat.getIntegerInstance(Locale.forLanguageTag("sk-SK")).format(watts) + " W";
    }

    private int[] readHoldingRegisters(String host, int port, int start, int count) throws IOException {
        int tx = (transactionId++ & 0xFFFF);
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(host, port), 2500);
            socket.setSoTimeout(2500);
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            DataInputStream in = new DataInputStream(socket.getInputStream());
            out.writeShort(tx);       // transaction id
            out.writeShort(0);        // protocol id
            out.writeShort(6);        // bytes after this field
            out.writeByte(UNIT_ID);
            out.writeByte(3);         // read holding registers
            out.writeShort(start);
            out.writeShort(count);
            out.flush();

            int responseTx = in.readUnsignedShort();
            int protocol = in.readUnsignedShort();
            int length = in.readUnsignedShort();
            int unit = in.readUnsignedByte();
            if (responseTx != tx || protocol != 0 || unit != UNIT_ID || length < 3) {
                throw new IOException("Neplatná odpoveď meniča");
            }
            int function = in.readUnsignedByte();
            if ((function & 0x80) != 0) {
                int code = in.readUnsignedByte();
                throw new IOException("Modbus odmietol čítanie (kód " + code + ")");
            }
            int byteCount = in.readUnsignedByte();
            if (function != 3 || byteCount != count * 2) throw new IOException("Neočakávaná dĺžka dát");
            int[] regs = new int[count];
            for (int i = 0; i < count; i++) regs[i] = in.readUnsignedShort();
            return regs;
        }
    }

    private int toInt32(int high, int low) {
        return (high << 16) | low;
    }

    private void stopPolling() {
        connected = false;
        if (executor != null) {
            executor.shutdownNow();
            executor = null;
        }
    }

    @Override
    protected void onDestroy() {
        stopPolling();
        super.onDestroy();
    }
}
