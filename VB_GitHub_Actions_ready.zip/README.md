# GoodWe Live

Android app with an HTML dashboard hosted inside a WebView. A small native Android bridge reads a GoodWe GW10KN-ET PLUS+ directly over local Modbus TCP; it does not use cloud services or a separate data server.

- Modbus TCP port: `502`
- Modbus/TCP Unit ID: `0`
- Poll interval: 2 seconds
- Live readings: PV1 + PV2 generation, house consumption, and grid import/export
- No SEMS cloud, web API, data collector, or remote control

The phone must be connected to the same home Wi-Fi/LAN as the inverter. On Android 13 and newer, allow **Nearby devices** when prompted so the app can reach the inverter on the local network. Enter the inverter's local IP in the app; the port defaults to 502. The app assumes there is no battery installed. It calculates house load using GoodWe ET's formula: PV power minus signed active power.

## Build through the existing VB repository workflow

This project is packaged with `app/` at the ZIP root to match the existing `build-from-zip.yml` workflow in `rastotomko13-sudo/VB`. Upload the archive there as `VB_GitHub_Actions_ready.zip`; the workflow starts on push. In Actions, open the newest **Build APK from ZIP** run and download its APK artifact.

To build locally, open this folder with Android Studio or run `gradle assembleDebug` with Android SDK 35 installed.
