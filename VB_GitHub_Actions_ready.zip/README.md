# Virtuálna batéria SPP (Android)

Prvá verzia aplikácie pre Android. Všetky údaje sa ukladajú lokálne v telefóne.

Funkcie:
- prehľad vloženej a odobranej energie,
- odhad zostatku virtuálnej batérie,
- denný a mesačný prehľad,
- import ZSDIS exportu XLS/XLSX/CSV,
- automatické rozpoznanie bežných názvov P+/P-/odber/dodávka,
- ručné mapovanie stĺpcov pri neznámom formáte,
- odkaz na Distribučný portál ZSDIS,
- lokálna databáza IndexedDB.

Poznámka: v0.1 importuje exportované dáta. Plne automatické sťahovanie zo ZSDIS bude možné doplniť po overení aktuálneho prihlasovacieho a exportného toku portálu.
