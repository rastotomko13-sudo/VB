# Virtuálna batéria SPP v0.8.5

Android aplikácia pre priame načítanie 15-minútových intervalových dát zo ZSDIS a výpočet stavu virtuálnej batérie.

Nové vo v0.8.5:
- priame ZSDIS API sa už neagreguje na dni; ukladajú sa jednotlivé 15-minútové intervaly,
- opravený denný súčet – vzniká sčítaním uložených 15-minútových intervalov,
- na Prehľade je posledný dostupný 15-minútový interval P− / P+ a jeho bilancia,
- História má režimy Deň / Mesiac / Všetko,
- v režime Deň sa dá zvoliť ľubovoľný krok po 15 minútach (15, 30, 45, 60 ... až 1440 min),
- režim Mesiac zobrazí denné súčty vybraného mesiaca,
- režim Všetko zobrazí všetky denné súčty,
- zachovaná kontrola ONLINE / NEPRIHLÁSENÝ / OFFLINE, uložené prihlásenie a hodinová synchronizácia.

Poznámka: posledný 15-minútový interval je posledný interval, ktorý ZSDIS reálne poskytol. Ak ZSDIS zverejňuje dáta s oneskorením, aplikácia zobrazí čas posledného dostupného merania.
