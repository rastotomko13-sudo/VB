# Virtuálna batéria SPP v0.8.0

Priame načítanie ZSDIS cez interné API zistené diagnostikou v0.7.0.

- bez klikania na Intervalové dáta
- bez exportu XLS/CSV
- po prihlásení sa zisťuje používateľ, odberné/výrobné miesto a ID dynamicky
- intervalové dáta sa sťahujú po 3-dňových blokoch
- ZSDIS vracia výkon v kW; denná energia sa počíta z hourlyConsumption (fallback 15 min × 0,25 h)
