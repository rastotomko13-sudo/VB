# GoodWe Live

Android app for direct, read-only monitoring of a GoodWe GW10KN-ET PLUS+ inverter over local Modbus TCP.

- Modbus TCP port: `502`
- Modbus/TCP Unit ID: `0`
- Poll interval: 2 seconds
- Live readings: PV1 + PV2 generation, house consumption, and grid import/export
- No SEMS cloud, web API, data collector, or remote control

The phone must be connected to the same home Wi-Fi/LAN as the inverter. Enter the inverter's local IP in the app; the port defaults to 502. The app assumes there is no battery installed. It derives house load as PV generation minus signed grid power, matching the GoodWe ET meter sign convention used by the existing local GoodWe readings.

## Build through the existing VB repository workflow

This project is packaged with `app/` at the ZIP root to match the existing `build-from-zip.yml` workflow in `rastotomko13-sudo/VB`. Upload the archive there as `VB_GitHub_Actions_ready.zip`; the workflow starts on push. In Actions, open the newest **Build APK from ZIP** run and download its APK artifact.

To build locally, open this folder with Android Studio or run `gradle assembleDebug` with Android SDK 35 installed.
