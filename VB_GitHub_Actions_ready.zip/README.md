# Virtuálna batéria SPP v0.5.4

Android aplikácia s automatickým načítaním intervalových dát zo ZSDIS cez GeckoView/Firefox engine.

- zelené tlačidlo **Aktualizovať zo ZSDIS** spustí automatické stiahnutie P+ a P−
- modré tlačidlo **Prihlásiť / ZSDIS** slúži na prihlásenie alebo kontrolu portálu
- ručný import ostáva len ako záloha
- opravené spájanie P+ a P− podľa rovnakého 15-minútového intervalu (druhá fáza už neprepíše prvú)
- v hlavičke je viditeľné číslo verzie v0.5.4, aby sa dalo overiť, že je nainštalovaná správna APK


## v0.5.4
- GeckoView pinned to stable 143.0.20251003115653 for compileSdk 35 / AGP 8.7.3 compatibility.
- Keeps automatic ZSDIS update controls from v0.5.3.
