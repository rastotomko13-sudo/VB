# Virtuálna batéria SPP – Android v0.6.0

Verzia 0.6 mení spôsob získavania dát zo ZSDIS:

- už sa nespolieha na automatické klikanie po portáli,
- vstavaný Firefox/GeckoView zachytí interné požiadavky, ktorými samotný Distribučný portál načítava intervalové dáta,
- pri prvom použití sa tieto API požiadavky jednorazovo naučia z prihlásenej relácie,
- následné aktualizácie sa vykonávajú priamo cez naučené API s rovnakou reláciou,
- aplikácia neukladá heslo,
- naučené API údaje zostávajú iba v úložisku aplikácie v telefóne.

## Prvé použitie

1. Stlač **Aktualizovať zo ZSDIS**.
2. Ak API ešte nie je naučené, otvorí sa ZSDIS.
3. Prihlás sa a jednorazovo otvor **Odberné miesta → Int. dáta**.
4. Zobraz profil **P+** a potom **P−**. Export nie je potrebný.
5. Aplikácia zachytí interné API požiadavky a následne už bude aktualizovať dáta priamo.

Ak portál používa textový kód `P_PLUS/P_MINUS`, aplikácia sa pokúsi druhý profil odvodiť automaticky, takže môže stačiť zobraziť iba jeden profil.
