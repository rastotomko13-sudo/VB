# Virtuálna batéria SPP v0.8.1

Oprava priameho ZSDIS API: requesty už nejdú z background extension kontextu, ale cez Firefox `content.fetch()` v kontexte otvorenej stránky Diportalu, aby sa použila správna first-party session/cookies a hlavičky stránky. Dopĺňa X-Requested-With a XSRF/CSRF hlavičky, ak ich Diportal používa.
