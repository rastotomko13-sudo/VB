# Virtuálna batéria SPP v0.5.5

Android aplikácia s automatickým načítaním intervalových dát zo ZSDIS cez GeckoView/Firefox engine.

- zelené tlačidlo **Aktualizovať zo ZSDIS** spustí automatické stiahnutie P+ a P−
- modré tlačidlo **Prihlásiť / ZSDIS** slúži na prihlásenie alebo kontrolu portálu
- ručný import ostáva len ako záloha
- opravené spájanie P+ a P− podľa rovnakého 15-minútového intervalu (druhá fáza už neprepíše prvú)
- v hlavičke je viditeľné číslo verzie v0.5.5, aby sa dalo overiť, že je nainštalovaná správna APK


## v0.5.5
- GeckoView pinned to stable 143.0.20251003115653 for compileSdk 35 / AGP 8.7.3 compatibility.
- Keeps automatic ZSDIS update controls from v0.5.3.


## v0.5.5
- opravená detekcia stránky: zoznam odberných miest sa už nemýli s Intervalovými dátami
- automatika klikne na viditeľné tlačidlo „Int. dáta“ pri zvolenom EIC
- za Intervalové dáta považuje stránku až po zobrazení formulára s dátumami
