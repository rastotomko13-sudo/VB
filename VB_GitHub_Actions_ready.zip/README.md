# Virtuálna batéria SPP – Android v0.2

Aplikácia sleduje vlastný odhad virtuálnej batérie SPP z intervalových dát ZSDIS.

## Nové vo v0.2
- zabudovaný ZSDIS/DI Portal priamo v aplikácii,
- jednorazové prihlásenie používateľa; aplikácia neukladá heslo, iba reláciu/cookies WebView,
- tlačidlo **Aktualizovať zo ZSDIS**,
- automatický pokus otvoriť Intervalové dáta, zvoliť odber P+ a dodávku P- a spustiť export,
- stiahnutý export sa importuje priamo do lokálnej databázy bez správcu súborov,
- ak sa zmení portál alebo relácia vyprší, aplikácia zobrazí ZSDIS a požiada o prihlásenie/pomoc.

Poznámka: webový portál ZSDIS nie je verejné zákaznícke API. Automatizácia je preto závislá od aktuálnej štruktúry portálu. Ručný import ostáva ako záloha.


## v0.3
Oprava bielej obrazovky pri prihlasovaní do ZSDIS: priama login route, browser-like User-Agent, podpora SPA nastavení a diagnostika WebView.
