# Virtuálna batéria SPP v0.8.3

Android aplikácia pre načítanie intervalových dát ZSDIS a výpočet stavu virtuálnej batérie.

Nové vo v0.8.3:
- ZSDIS prihlasovacie meno a heslo je možné uložiť priamo v aplikácii.
- Heslo je uložené šifrovane cez Android Keystore (AES-GCM), nie ako obyčajný text.
- Pri vypršaní relácie sa aplikácia pokúsi prihlásiť automaticky cez prihlasovaciu stránku ZSDIS.
- Synchronizácia sa spustí pri štarte aplikácie.
- Synchronizácia sa opakuje každých 60 minút počas behu aplikácie a pri návrate do aplikácie, ak posledná synchronizácia je staršia ako hodina.
- Zachované priame interné API ZSDIS pre odber a dodávku aj výpočet ceny virtuálnej batérie.

Poznámka: Android môže po dlhšom čase ukončiť proces aplikácie na pozadí. Táto verzia neudržiava trvalú foreground službu; hodinová synchronizácia beží, kým proces aplikácie zostáva aktívny.
