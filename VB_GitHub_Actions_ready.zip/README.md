# Virtuálna batéria SPP v0.5

Táto verzia používa Mozilla GeckoView (Firefox engine) pre Distribučný portál ZSDIS namiesto Android WebView.

- prihlásenie do ZSDIS priamo v aplikácii,
- lokálne uchovanie relácie v telefóne,
- WebExtension pomocník pre automatické otvorenie Odberných miest a Intervalových dát,
- pokus o automatické nastavenie obdobia a profilov odber/dodávka,
- zachytenie Excel/CSV exportu priamo v portáli a automatický import do aplikácie,
- lokálna databáza a výpočet zostatku virtuálnej batérie.

Poznámka: Diportal je SPA a môže meniť DOM. Ak automatika nenájde konkrétny krok, portál ostane otvorený a stačí ručne prejsť na Intervalové dáta; export aplikácia zachytí a importuje sama.
