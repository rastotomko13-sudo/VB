# Virtuálna batéria SPP v0.5.7

Android aplikácia s automatickým načítaním intervalových dát zo ZSDIS cez GeckoView/Firefox engine.

- zelené tlačidlo **Aktualizovať zo ZSDIS** spustí automatické stiahnutie P+ a P−
- modré tlačidlo **Prihlásiť / ZSDIS** slúži na prihlásenie alebo kontrolu portálu
- ručný import ostáva len ako záloha
- opravené spájanie P+ a P− podľa rovnakého 15-minútového intervalu (druhá fáza už neprepíše prvú)
- v hlavičke je viditeľné číslo verzie v0.5.7, aby sa dalo overiť, že je nainštalovaná správna APK


## v0.5.7
- GeckoView pinned to stable 143.0.20251003115653 for compileSdk 35 / AGP 8.7.3 compatibility.
- Keeps automatic ZSDIS update controls from v0.5.3.


## v0.5.7
- opravená detekcia stránky: zoznam odberných miest sa už nemýli s Intervalovými dátami
- automatika klikne na viditeľné tlačidlo „Int. dáta“ pri zvolenom EIC
- za Intervalové dáta považuje stránku až po zobrazení formulára s dátumami


## v0.5.7
Opravené rozpoznanie zoznamu odberných miest: texty „Dátum od/do“ v detaile EIC sa už nepovažujú za formulár intervalových dát. Kliknutie na „Int. dáta“ vyhľadáva aj vnorené span/div prvky a kliká na skutočný interaktívny rodič. Automatika následne pracuje iba s reálnymi editovateľnými dátumovými poľami.


## v0.5.7
- po prihlásení automaticky opustí Domov / Úvodnú stránku
- na mobile otvorí zbalené hamburger menu a zvolí Odberné miesta
- ak je odkaz na Odberné miesta už v DOM, použije ho priamo aj keď je menu skryté
