# Virtuálna batéria SPP v0.8.7

Opravený svetlý hlavný prehľad podľa vybraného návrhu.

Na hlavnej obrazovke zostáva:
- Zostatok VB,
- Do siete (P−) – celkovo dodaná energia,
- Zo siete (P+) – celkovo odobraná energia,
- Aktuálna cena / kWh,
- Celková cena z VB,
- História zostatku VB.

Z hlavnej obrazovky je odstránené:
- Využité z VB,
- blok Posledný 15-min interval.

Detailné 15-minútové údaje zostávajú v Histórii.
