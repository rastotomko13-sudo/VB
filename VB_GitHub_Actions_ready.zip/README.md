# Virtuálna batéria SPP – Android v0.7.0 DIAGNOSTIKA API

Táto verzia nie je vydávaná za hotovú automatizáciu. Jej úloha je najprv zistiť **skutočné interné API volanie**, ktoré Distribučný portál používa na intervalové dáta.

## Postup jedného merania

1. V aplikácii stlač **🧪 Zistiť interné API**.
2. Prihlás sa do ZSDIS (ak relácia ešte nie je prihlásená).
3. Manuálne prejdi na **Odberné miesta → Int. dáta** a nechaj portál zobraziť intervalové údaje. Nie je potrebný Export.
4. Vráť sa tlačidlom Späť do aplikácie.
5. Stlač **📋 Kopírovať diagnostiku** a vlož text do ChatGPT.

Diagnostika zaznamenáva URL/metódu požiadaviek, ne-tajné parametre, HTTP stav, typ a krátku ukážku odpovede. Hodnoty hlavičiek Authorization/Cookie a parametre typu token/password/session/secret sú v exportovanom texte odstránené.

Až z tohto konkrétneho requestu sa má pripraviť finálna verzia, ktorá bude volať endpoint priamo.
